import type { NextConfig } from "next";

const nextConfig: NextConfig = {

  images: {
    remotePatterns: [
      { protocol: "https", hostname: "hr-y.com" },
      { protocol: "https", hostname: "images.pexels.com" },
      { protocol: "https", hostname: "t2.gstatic.com" },
      { protocol: "https", hostname: "wembsmkt.com" },
      { protocol: "https", hostname: "play-lh.googleusercontent.com" },
      { protocol: "https", hostname: "logodix.com" },
      { protocol: "https", hostname: "encrypted-tbn0.gstatic.com" },
      { protocol: "https", hostname: "abetter.bid" },
      { protocol: "https", hostname: "angliacarauctions.co.uk" },
    ],
  },
};

export default nextConfig;
