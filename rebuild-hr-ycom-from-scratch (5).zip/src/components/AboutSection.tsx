import { Users, Zap, Shield, DollarSign } from "lucide-react";
import type { Dictionary } from "@/lib/i18n";

export default function AboutSection({ t }: { t: Dictionary }) {
  const features = [
    { title: t.about.f1, desc: t.about.f1d, icon: <Users className="w-7 h-7" /> },
    { title: t.about.f2, desc: t.about.f2d, icon: <Zap className="w-7 h-7" /> },
    { title: t.about.f3, desc: t.about.f3d, icon: <Shield className="w-7 h-7" /> },
    { title: t.about.f4, desc: t.about.f4d, icon: <DollarSign className="w-7 h-7" /> },
  ];
  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">{t.about.badge}</span>
          <h2 className="section-title">{t.about.title}</h2>
          <p className="section-subtitle mt-4">{t.about.subtitle}</p>
          <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
        </div>
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="grid sm:grid-cols-2 gap-6">
            {features.map((f, i) => (
              <div key={f.title} className={`bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100 hover:border-secondary/30 group hover:-translate-y-1 ${i % 2 === 1 ? "sm:mt-8" : ""}`}>
                <div className="w-14 h-14 bg-primary/5 rounded-xl flex items-center justify-center text-primary mb-4 group-hover:bg-secondary group-hover:text-white transition-all duration-300">{f.icon}</div>
                <h3 className="text-lg font-bold text-primary mb-3">{f.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img src="https://hr-y.com/assets/images/frontend/about/6585c6d8417551703266008.png" alt={t.about.imgAlt} className="w-full h-[500px] object-cover bg-primary" />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <h3 className="text-white text-2xl font-bold mb-2">{t.about.expTitle}</h3>
                <p className="text-white/80 text-sm">{t.about.expSub}</p>
              </div>
            </div>
            <div className="absolute -top-6 -right-6 bg-secondary text-white rounded-2xl p-6 shadow-2xl animate-pulse-glow">
              <div className="text-3xl font-black">+15</div>
              <div className="text-sm font-medium">{t.about.yearsExp}</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
