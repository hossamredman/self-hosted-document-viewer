import Link from "next/link";
import { ArrowLeft, ArrowRight, Briefcase, Calculator, CheckCircle2, ClipboardList, FileCheck, Gavel, Package, Plane, Search, Ship, ShoppingCart, Truck, Warehouse } from "lucide-react";
import type { Dictionary, Locale } from "@/lib/i18n";
import { services } from "@/lib/data";

const iconMap: Record<string, React.ElementType> = {
  ShoppingCart,
  Gavel,
  Truck,
  ClipboardList,
  Calculator,
  Ship,
  Package,
  Briefcase,
  FileCheck,
  Plane,
  Warehouse,
  Search,
};

export default function ServicesSection({ t, locale, showAll = false }: { t: Dictionary; locale: Locale; showAll?: boolean }) {
  const isAr = locale === "ar";
  const p = isAr ? "" : "/en";
  const Arrow = isAr ? ArrowLeft : ArrowRight;
  const displayed = showAll ? services : services.slice(0, 8);

  return (
    <section className="section-light py-24">
      <div className="absolute inset-0 opacity-60" style={{ backgroundImage: "radial-gradient(circle at 15% 20%, rgba(214,180,90,.22), transparent 28%), radial-gradient(circle at 90% 10%, rgba(37,215,255,.12), transparent 28%)" }} />
      <div className="container-soft relative z-10">
        <div className="grid gap-10 lg:grid-cols-[.75fr_1.25fr] lg:items-end">
          <div>
            <div className="eyebrow border-primary/10 bg-primary/5 text-primary">
              {isAr ? "هندسة الخدمات" : "Service Engineering"}
            </div>
            <h2 className="mt-5 text-4xl font-black leading-tight text-primary md:text-6xl">
              {isAr ? "كل ما تحتاجه الشحنة في نظام واحد" : "Everything your cargo needs in one system"}
            </h2>
          </div>
          <p className="max-w-3xl text-lg leading-9 text-primary/65">
            {isAr
              ? "بدلاً من عرض خدمات تقليدي، بنينا منظومة تشغيل: شراء، مزايدة، فحص، شحن، تخزين، تخليص، تصاريح، احتساب، وتسليم نهائي."
              : "Not a traditional service list; this is an operating system: buying, bidding, inspection, shipping, warehousing, clearance, permits, costing, and final delivery."}
          </p>
        </div>

        <div className="mt-14 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {displayed.map((service, index) => {
            const Icon = iconMap[service.icon] || Package;
            const title = isAr ? service.titleAr : service.titleEn;
            const short = isAr ? service.shortAr : service.shortEn;
            const features = isAr ? service.features : service.featuresEn;
            return (
              <article key={service.id} className={`bento-light group ${index === 0 || index === 5 ? "xl:col-span-2" : ""}`}>
                <div className="flex items-start justify-between gap-4">
                  <div className={`grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br ${service.color} shadow-lg`}>
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  <span className="text-5xl font-black text-primary/5 transition group-hover:text-secondary/20">{String(index + 1).padStart(2, "0")}</span>
                </div>
                <h3 className="mt-6 text-2xl font-black text-primary">{title}</h3>
                <p className="mt-3 min-h-16 text-sm leading-7 text-primary/60">{short}</p>
                <div className="mt-5 grid gap-2">
                  {features.slice(0, 3).map((feature) => (
                    <div key={feature} className="flex items-center gap-2 text-sm font-bold text-primary/70">
                      <CheckCircle2 className="h-4 w-4 text-secondary" />
                      {feature}
                    </div>
                  ))}
                </div>
              </article>
            );
          })}
        </div>

        {!showAll && (
          <div className="mt-12 text-center">
            <Link href={`${p}/services`} className="btn-primary">
              {isAr ? "افتح كل الخدمات والتفاصيل" : "Open all services & details"} <Arrow className="h-5 w-5" />
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
