"use client";
import { useState } from "react";
import { Send, Loader2 } from "lucide-react";
import toast from "react-hot-toast";
import type { Dictionary } from "@/lib/i18n";

export default function ContactForm({ t }: { t: Dictionary }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [loading, setLoading] = useState(false);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Static site - show success directly
    setTimeout(() => {
      toast.success(t.contact.success);
      setForm({ name: "", email: "", phone: "", subject: "", message: "" });
      setLoading(false);
    }, 1000);
  };
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div><label className="block text-sm font-medium text-gray-700 mb-2">{t.contact.name} *</label><input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all text-gray-700" /></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-2">{t.contact.emailLabel} *</label><input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all text-gray-700" /></div>
      </div>
      <div className="grid md:grid-cols-2 gap-6">
        <div><label className="block text-sm font-medium text-gray-700 mb-2">{t.contact.phoneLabel}</label><input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all text-gray-700" /></div>
        <div><label className="block text-sm font-medium text-gray-700 mb-2">{t.contact.subject}</label><input type="text" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all text-gray-700" /></div>
      </div>
      <div><label className="block text-sm font-medium text-gray-700 mb-2">{t.contact.message} *</label><textarea required rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all resize-none text-gray-700" /></div>
      <button type="submit" disabled={loading} className="btn-primary w-full py-4 text-lg flex items-center justify-center gap-3 disabled:opacity-50">
        {loading ? <><Loader2 className="w-5 h-5 animate-spin" /><span>{t.contact.sending}</span></> : <><Send className="w-5 h-5" /><span>{t.contact.send}</span></>}
      </button>
    </form>
  );
}
