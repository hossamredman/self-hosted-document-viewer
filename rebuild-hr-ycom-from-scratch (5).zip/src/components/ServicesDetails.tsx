import Link from "next/link";
import type { ReactNode } from "react";
import { CheckCircle, ArrowLeft, ArrowRight, FileText, Search, Calculator, Truck, ShieldCheck, Headphones, Clock, Globe2, PackageCheck } from "lucide-react";
import type { Locale } from "@/lib/i18n";
import { services, shoppingWebsites, auctionWebsites, shippingAgencies, yemenPorts } from "@/lib/data";

const processIcons = [Search, FileText, Calculator, Truck, ShieldCheck, PackageCheck];

const processAr = [
  { title: "دراسة الطلب", desc: "نراجع تفاصيل البضاعة والوجهة والمستندات المطلوبة." },
  { title: "تجهيز الوثائق", desc: "نجهز الفواتير والشهادات والتصاريح والبيانات الجمركية." },
  { title: "احتساب التكلفة", desc: "نقدم تقديراً واضحاً للرسوم والجمارك والشحن." },
  { title: "الشحن والنقل", desc: "نرتب وسيلة الشحن المناسبة بحرياً أو جوياً أو برياً." },
  { title: "التخليص والمتابعة", desc: "نتابع المعاملة في الجمارك حتى الإفراج النهائي." },
  { title: "التسليم النهائي", desc: "نسلم الشحنة للعميل أو للمخزن حسب الاتفاق." },
];

const processEn = [
  { title: "Request Study", desc: "We review cargo details, destination, and required documents." },
  { title: "Documentation", desc: "We prepare invoices, certificates, permits, and customs forms." },
  { title: "Costing", desc: "We provide a clear estimate of duties, fees, and freight." },
  { title: "Shipping", desc: "We arrange the right sea, air, or land shipping method." },
  { title: "Clearance", desc: "We follow the customs process until final release." },
  { title: "Delivery", desc: "We deliver the shipment to the client or warehouse as agreed." },
];

export default function ServicesDetails({ locale }: { locale: Locale }) {
  const isAr = locale === "ar";
  const p = isAr ? "" : "/en";
  const Arrow = isAr ? ArrowLeft : ArrowRight;
  const process = isAr ? processAr : processEn;

  return (
    <>
      {/* Full service details */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">
              {isAr ? "تفاصيل الخدمات" : "Service Details"}
            </span>
            <h2 className="section-title">
              {isAr ? "كل خدمة بتفاصيلها وأقسامها" : "Every Service with Details & Sections"}
            </h2>
            <p className="section-subtitle mt-4">
              {isAr
                ? "وسعنا الخدمات لتغطي كل مراحل الاستيراد والتصدير والشحن والتخليص والشراء والمزايدات."
                : "Expanded services covering every stage of import, export, shipping, clearance, purchasing, and auctions."}
            </p>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          <div className="space-y-8">
            {services.map((service, index) => (
              <div key={service.id} className="bg-gray-50 rounded-3xl overflow-hidden border border-gray-100 hover:border-secondary/30 hover:shadow-xl transition-all duration-300">
                <div className="grid lg:grid-cols-12 gap-0">
                  <div className={`lg:col-span-4 bg-gradient-to-br ${service.color} p-8 text-white relative overflow-hidden`}>
                    <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, white 0, transparent 30%)" }} />
                    <span className="text-white/50 text-6xl font-black">{String(index + 1).padStart(2, "0")}</span>
                    <h3 className="text-2xl font-black mt-4 mb-3">{isAr ? service.titleAr : service.titleEn}</h3>
                    <p className="text-white/85 leading-relaxed">{isAr ? service.shortAr : service.shortEn}</p>
                  </div>

                  <div className="lg:col-span-8 p-8">
                    <p className="text-gray-700 leading-relaxed mb-6">{isAr ? service.descAr : service.descEn}</p>
                    <div className="grid sm:grid-cols-2 gap-3 mb-6">
                      {(isAr ? service.features : service.featuresEn).map((feature) => (
                        <div key={feature} className="flex items-center gap-3 bg-white rounded-xl p-3 shadow-sm">
                          <CheckCircle className="w-5 h-5 text-secondary shrink-0" />
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                    <Link href={`${p}/contact`} className="inline-flex items-center gap-2 text-secondary font-bold hover:gap-3 transition-all">
                      {isAr ? "اطلب الخدمة الآن" : "Request this service"}
                      <Arrow className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Work process */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">
              {isAr ? "منهجية العمل" : "Workflow"}
            </span>
            <h2 className="section-title">{isAr ? "كيف ننفذ طلبك؟" : "How We Execute Your Request"}</h2>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {process.map((step, i) => {
              const Icon = processIcons[i];
              return (
                <div key={step.title} className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover:border-secondary/30 hover:-translate-y-1 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 bg-primary/5 rounded-xl flex items-center justify-center text-primary shrink-0">
                      <Icon className="w-7 h-7" />
                    </div>
                    <div>
                      <span className="text-secondary text-sm font-black">0{i + 1}</span>
                      <h3 className="text-lg font-bold text-primary mb-2">{step.title}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Supported platforms and ports */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="bg-primary rounded-3xl p-8 text-white">
              <ShoppingTitle icon={<Globe2 className="w-8 h-8" />} title={isAr ? "مواقع الشراء" : "Shopping Platforms"} />
              <div className="grid grid-cols-2 gap-3 mt-6">
                {shoppingWebsites.slice(0, 10).map((site) => (
                  <div key={site.name} className="bg-white/10 rounded-xl px-3 py-2 text-sm">{isAr ? site.nameAr : site.name}</div>
                ))}
              </div>
            </div>

            <div className="bg-secondary rounded-3xl p-8 text-white">
              <ShoppingTitle icon={<Clock className="w-8 h-8" />} title={isAr ? "مواقع المزادات" : "Auction Platforms"} />
              <div className="grid grid-cols-2 gap-3 mt-6">
                {auctionWebsites.slice(0, 10).map((site) => (
                  <div key={site.name} className="bg-white/15 rounded-xl px-3 py-2 text-sm">{isAr ? site.nameAr : site.name}</div>
                ))}
              </div>
            </div>

            <div className="bg-primary-dark rounded-3xl p-8 text-white">
              <ShoppingTitle icon={<Headphones className="w-8 h-8" />} title={isAr ? "المنافذ والوكالات" : "Ports & Agencies"} />
              <div className="space-y-3 mt-6">
                <div className="bg-white/10 rounded-xl px-3 py-2 text-sm">{yemenPorts.sea.length} {isAr ? "موانئ بحرية" : "Sea Ports"}</div>
                <div className="bg-white/10 rounded-xl px-3 py-2 text-sm">{yemenPorts.land.length} {isAr ? "منافذ برية" : "Land Borders"}</div>
                <div className="bg-white/10 rounded-xl px-3 py-2 text-sm">{shippingAgencies.length} {isAr ? "وكالة شحن" : "Shipping Agencies"}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function ShoppingTitle({ icon, title }: { icon: ReactNode; title: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-14 h-14 bg-white/15 rounded-2xl flex items-center justify-center">{icon}</div>
      <h3 className="text-xl font-black">{title}</h3>
    </div>
  );
}
