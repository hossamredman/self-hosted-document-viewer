"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Globe2, Menu, Phone, Radar, X } from "lucide-react";
import type { Dictionary, Locale } from "@/lib/i18n";
import { LOGO_URL, SLOGAN_AR, SLOGAN_EN } from "@/lib/data";

function path(locale: Locale, href: string) {
  return locale === "en" ? `/en${href === "/" ? "" : href}` : href;
}

export default function Header({ t, locale }: { t: Dictionary; locale: Locale }) {
  const [open, setOpen] = useState(false);
  const [solid, setSolid] = useState(false);
  const isAr = locale === "ar";
  const links = [
    [path(locale, "/"), t.nav.home],
    [path(locale, "/services"), t.nav.services],
    [path(locale, "/branches"), isAr ? "الشبكة" : "Network"],
    [path(locale, "/team"), isAr ? "الفريق" : "Team"],
    [path(locale, "/partners"), isAr ? "الشركاء" : "Partners"],
    [path(locale, "/contact"), t.nav.contact],
  ];

  useEffect(() => {
    const fn = () => setSolid(window.scrollY > 24);
    fn();
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3">
      <div className={`mx-auto max-w-7xl rounded-[1.7rem] border px-3 py-3 transition-all duration-500 ${solid ? "border-white/10 bg-primary-dark/85 shadow-2xl shadow-black/30 backdrop-blur-2xl" : "border-white/10 bg-white/5 backdrop-blur-xl"}`}>
        <div className="flex items-center justify-between gap-3">
          <Link href={path(locale, "/")} className="flex items-center gap-3">
            <span className="relative grid h-14 w-14 place-items-center rounded-2xl bg-white shadow-lg shadow-black/20">
              <Image src={LOGO_URL} alt="HR-Y" fill className="object-contain p-1.5" unoptimized priority />
            </span>
            <span className="hidden sm:block leading-tight">
              <span className="block text-base font-black text-white">{isAr ? "حسام ردمان" : "Hussam Radman"}</span>
              <span className="block text-xs font-bold text-secondary">{isAr ? SLOGAN_AR : SLOGAN_EN}</span>
            </span>
          </Link>

          <nav className="hidden items-center gap-1 xl:flex">
            {links.map(([href, label]) => (
              <Link key={href} href={href} className="rounded-full px-4 py-2 text-sm font-bold text-white/75 transition hover:bg-white/10 hover:text-secondary">
                {label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Link href={path(locale, "/track")} className="hidden rounded-full border border-accent/25 bg-accent/10 px-4 py-2 text-sm font-black text-accent transition hover:bg-accent/20 lg:inline-flex items-center gap-2">
              <Radar className="h-4 w-4" /> {t.nav.track}
            </Link>
            <a href="tel:+967778877011" className="hidden h-11 w-11 place-items-center rounded-full bg-secondary text-primary-dark shadow-lg shadow-secondary/20 transition hover:scale-105 md:grid">
              <Phone className="h-5 w-5" />
            </a>
            <Link href={t.nav.switchLangPath} className="grid h-11 w-11 place-items-center rounded-full border border-white/10 bg-white/5 text-white transition hover:text-secondary">
              <Globe2 className="h-5 w-5" />
            </Link>
            <button onClick={() => setOpen(!open)} className="grid h-11 w-11 place-items-center rounded-full border border-white/10 bg-white/5 text-white xl:hidden">
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        <div className={`xl:hidden overflow-hidden transition-all duration-500 ${open ? "max-h-96 pt-3" : "max-h-0"}`}>
          <div className="grid gap-1 rounded-2xl border border-white/10 bg-black/20 p-2">
            {links.map(([href, label]) => (
              <Link key={href} onClick={() => setOpen(false)} href={href} className="rounded-xl px-4 py-3 text-sm font-bold text-white/80 hover:bg-white/10 hover:text-secondary">
                {label}
              </Link>
            ))}
            <Link onClick={() => setOpen(false)} href={path(locale, "/track")} className="rounded-xl px-4 py-3 text-sm font-black text-accent hover:bg-white/10">
              {t.nav.track}
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
