import { FileCheck2, MonitorUp, ScanSearch } from "lucide-react";
import type { Dictionary } from "@/lib/i18n";

export default function StepsSection({ t }: { t: Dictionary }) {
  const steps = [
    { n: "01", title: t.steps.s1Title, desc: t.steps.s1Desc, icon: MonitorUp },
    { n: "02", title: t.steps.s2Title, desc: t.steps.s2Desc, icon: FileCheck2 },
    { n: "03", title: t.steps.s3Title, desc: t.steps.s3Desc, icon: ScanSearch },
  ];
  return (
    <section className="section-light py-24">
      <div className="container-soft">
        <div className="mx-auto mb-14 max-w-3xl text-center">
          <span className="eyebrow border-primary/10 bg-primary/5 text-primary">{t.steps.badge}</span>
          <h2 className="mt-5 text-4xl font-black text-primary md:text-5xl">{t.steps.title}</h2>
        </div>
        <div className="relative grid gap-5 md:grid-cols-3">
          <div className="absolute left-0 right-0 top-16 hidden h-px bg-gradient-to-r from-transparent via-secondary/40 to-transparent md:block" />
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.n} className="bento-light relative text-center">
                <div className="mx-auto mb-5 grid h-20 w-20 place-items-center rounded-[1.7rem] bg-primary text-secondary shadow-xl shadow-primary/10">
                  <Icon className="h-9 w-9" />
                </div>
                <span className="absolute start-6 top-6 text-5xl font-black text-primary/5">{step.n}</span>
                <h3 className="text-xl font-black text-primary">{step.title}</h3>
                <p className="mt-3 text-sm leading-7 text-primary/60">{step.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
