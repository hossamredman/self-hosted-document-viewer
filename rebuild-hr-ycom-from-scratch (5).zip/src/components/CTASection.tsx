import Link from "next/link";
import { Mail, Phone } from "lucide-react";
import type { Dictionary, Locale } from "@/lib/i18n";

export default function CTASection({ t, locale }: { t: Dictionary; locale: Locale }) {
  const p = locale === "en" ? "/en" : "";
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('https://images.pexels.com/photos/20216716/pexels-photo-20216716.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=2000')` }} />
      <div className="absolute inset-0 bg-gradient-to-r from-primary-dark/95 via-primary/90 to-primary-dark/95" />
      <div className="container mx-auto px-4 relative z-10 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-secondary/20 text-secondary border border-secondary/30 px-4 py-2 rounded-full text-sm font-medium mb-6"><span className="w-2 h-2 bg-secondary rounded-full animate-pulse" />{t.cta.badge}</div>
          <h2 className="text-3xl md:text-5xl font-black text-white mb-6 leading-tight">{t.cta.title1}<br /><span className="text-secondary">{t.cta.title2}</span></h2>
          <p className="text-white/80 text-lg mb-10 max-w-xl mx-auto leading-relaxed">{t.cta.desc}</p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href={`${p}/contact`} className="btn-primary text-lg px-10 py-4 inline-flex items-center gap-3"><Mail className="w-5 h-5" /><span>{t.cta.cta1}</span></Link>
            <a href="tel:+967778877011" className="btn-outline text-lg px-10 py-4 inline-flex items-center gap-3"><Phone className="w-5 h-5" /><span dir="ltr">+967 778877011</span></a>
          </div>
        </div>
      </div>
    </section>
  );
}
