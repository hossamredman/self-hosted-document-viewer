import Image from "next/image";
import { Anchor, Building2, CircleDot, Plane, RadioTower, Ship, Truck, UsersRound } from "lucide-react";
import type { Locale } from "@/lib/i18n";
import { branches, LOGO_URL, SLOGAN_AR, SLOGAN_EN, APP_INFO, shippingAgencies, shoppingWebsites, statistics, teamMembers, yemenPorts, additionalServices } from "@/lib/data";

export default function CommandCenterSection({ locale }: { locale: Locale }) {
  const isAr = locale === "ar";
  return (
    <section className="section-dark py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(37,215,255,.14),transparent_30%),radial-gradient(circle_at_5%_70%,rgba(214,180,90,.18),transparent_25%)]" />
      <div className="container-soft relative z-10">
        <div className="mb-14 text-center">
          <span className="eyebrow"><RadioTower className="h-4 w-4" /> {isAr ? "ثقة بقدر المسؤولية" : "Trust Equals Responsibility"}</span>
          <h2 className="mx-auto mt-5 max-w-4xl text-4xl font-black leading-tight text-white md:text-6xl">
            {isAr ? "ذكاء اصطناعي يدير الموانئ والمنافذ والوكالات والمواقع في منصة واحدة" : "AI managing ports, borders, agencies, and platforms in one unified platform"}
          </h2>
        </div>

        <div className="grid gap-5 lg:grid-cols-12">
          <div className="bento-card lg:col-span-5 lg:row-span-2">
            <div className="flex items-center gap-4">
              <div className="relative h-16 w-16 rounded-2xl bg-white p-2">
                <Image src={LOGO_URL} alt="HR" fill className="object-contain p-2" unoptimized />
              </div>
              <div>
                <h3 className="text-2xl font-black text-white">HR-Y Command OS</h3>
                <p className="text-sm font-bold text-secondary">{isAr ? `تطبيق ${APP_INFO.nameAr} | تشغيل حي` : `${APP_INFO.nameEn} App | Live Ops`}</p>
              </div>
            </div>
            <div className="mt-8 rounded-3xl border border-white/10 bg-black/25 p-5">
              {[
                [isAr ? "قيد التخليص" : "In clearance", "74%", "bg-secondary"],
                [isAr ? "قيد الشحن" : "In transit", "52%", "bg-accent"],
                [isAr ? "جاهز للتسليم" : "Ready delivery", "89%", "bg-emerald-400"],
              ].map(([label, pct, color]) => (
                <div key={label} className="mb-5 last:mb-0">
                  <div className="mb-2 flex justify-between text-sm font-bold text-white/70"><span>{label}</span><span>{pct}</span></div>
                  <div className="h-2 overflow-hidden rounded-full bg-white/10"><div className={`h-full rounded-full ${color}`} style={{ width: pct }} /></div>
                </div>
              ))}
            </div>
          </div>

          <StatCard icon={<Building2 />} value={`${branches.length}+`} label={isAr ? "فروع ومنافذ" : "Branches & ports"} />
          <StatCard icon={<UsersRound />} value={`${teamMembers.length}+`} label={isAr ? "خبراء وفريق" : "Experts & team"} />
          <StatCard icon={<Ship />} value={`${shippingAgencies.length}+`} label={isAr ? "وكالة شحن" : "Shipping agencies"} />
          <StatCard icon={<CircleDot />} value={`${statistics.completedTransactions.toLocaleString()}+`} label={isAr ? "عملية منجزة" : "Completed ops"} />

          <div className="bento-card lg:col-span-4">
            <h3 className="mb-5 text-xl font-black text-white">{isAr ? "المنافذ المدعومة بالذكاء الاصطناعي" : "AI-Powered Ports"}</h3>
            <div className="grid grid-cols-3 gap-3">
              <Mini icon={<Anchor />} label={`${yemenPorts.sea.length} ${isAr ? "بحري" : "Sea"}`} />
              <Mini icon={<Truck />} label={`${yemenPorts.land.length} ${isAr ? "بري" : "Land"}`} />
              <Mini icon={<Plane />} label={`${yemenPorts.air.length} ${isAr ? "جوي" : "Air"}`} />
            </div>
          </div>

          <div className="bento-card lg:col-span-3">
            <h3 className="mb-4 text-xl font-black text-white">{isAr ? "مواقع الشراء" : "Shopping"}</h3>
            <div className="flex flex-wrap gap-2">
              {shoppingWebsites.slice(0, 8).map((site) => (
                <span key={site.name} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-bold text-white/65">{isAr ? site.nameAr : site.name}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function StatCard({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="bento-card lg:col-span-3">
      <div className="mb-5 grid h-12 w-12 place-items-center rounded-2xl bg-secondary/15 text-secondary">{icon}</div>
      <div className="text-4xl font-black text-white">{value}</div>
      <div className="mt-2 text-sm font-bold text-white/50">{label}</div>
    </div>
  );
}

function Mini({ icon, label }: { icon: React.ReactNode; label: string }) {
  return <div className="rounded-2xl bg-white/5 p-4 text-center text-white/70"><div className="mx-auto mb-2 grid h-9 w-9 place-items-center rounded-xl bg-secondary/15 text-secondary">{icon}</div><div className="text-xs font-black">{label}</div></div>;
}
