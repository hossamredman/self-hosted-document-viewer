import Link from "next/link";
import type { Dictionary, Locale } from "@/lib/i18n";

const posts = [
  { id: 1, titleAr: "أهمية التخليص الجمركي في التجارة الدولية", titleEn: "Importance of Customs Clearance in International Trade", slug: "importance-of-customs-clearance", excerptAr: "استكشف أهمية التخليص الجمركي ودوره الحيوي في تسهيل التجارة الدولية وحركة البضائع عبر الحدود.", excerptEn: "Explore the importance of customs clearance and its vital role in facilitating international trade.", img: "https://images.pexels.com/photos/20581299/pexels-photo-20581299.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600", date: "2024-09-25" },
  { id: 2, titleAr: "دليلك الشامل لاستيراد البضائع إلى اليمن", titleEn: "Your Complete Guide to Importing Goods to Yemen", slug: "guide-to-importing-goods", excerptAr: "كل ما تحتاج معرفته حول إجراءات ومتطلبات استيراد البضائع إلى الجمهورية اليمنية.", excerptEn: "Everything you need to know about procedures and requirements for importing goods.", img: "https://images.pexels.com/photos/24246926/pexels-photo-24246926.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600", date: "2024-09-25" },
  { id: 3, titleAr: "كيف تختار شركة الشحن المناسبة لبضائعك", titleEn: "How to Choose the Right Shipping Company", slug: "how-to-choose-shipping-company", excerptAr: "نصائح وإرشادات مهمة لاختيار شركة الشحن الأنسب لتلبية احتياجاتك التجارية.", excerptEn: "Important tips for choosing the best shipping company for your business needs.", img: "https://images.pexels.com/photos/33537946/pexels-photo-33537946.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600", date: "2024-09-25" },
];

export default function BlogSection({ t, locale }: { t: Dictionary; locale: Locale }) {
  const p = locale === "en" ? "/en" : "";
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">{t.blog.badge}</span>
          <h2 className="section-title">{t.blog.title}</h2>
          <p className="section-subtitle mt-4">{t.blog.subtitle}</p>
          <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {posts.map((post) => { const d = new Date(post.date); return (
            <Link key={post.id} href={`${p}/blog/${post.slug}`} className="group">
              <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100 hover:border-secondary/30">
                <div className="relative h-52 overflow-hidden">
                  <img src={post.img} alt={locale === "ar" ? post.titleAr : post.titleEn} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute top-4 left-4 bg-secondary text-white rounded-xl px-3 py-2 text-center shadow-lg"><div className="text-lg font-bold leading-none">{d.getDate()}</div><div className="text-xs mt-1">{d.toLocaleDateString(locale === "ar" ? "ar-YE" : "en-US", { month: "short" })}</div></div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-bold text-primary mb-3 group-hover:text-secondary transition-colors line-clamp-2">{locale === "ar" ? post.titleAr : post.titleEn}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">{locale === "ar" ? post.excerptAr : post.excerptEn}</p>
                  <div className="mt-4 flex items-center gap-2 text-secondary text-sm font-medium">{t.blog.readMore}</div>
                </div>
              </div>
            </Link>
          ); })}
        </div>
        <div className="text-center mt-12"><Link href={`${p}/blog`} className="btn-primary inline-flex items-center gap-2"><span>{t.blog.viewAll}</span></Link></div>
      </div>
    </section>
  );
}
