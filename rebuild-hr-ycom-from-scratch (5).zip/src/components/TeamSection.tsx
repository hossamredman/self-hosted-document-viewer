import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowRight, BadgeCheck, CalendarDays, Crown, UsersRound } from "lucide-react";
import type { Dictionary } from "@/lib/i18n";
import { teamMembers } from "@/lib/data";

export default function TeamSection({ t, locale, showAll = false }: { t: Dictionary; locale: string; showAll?: boolean }) {
  const isAr = locale === "ar";
  const p = isAr ? "" : "/en";
  const Arrow = isAr ? ArrowLeft : ArrowRight;
  const displayed = showAll ? teamMembers : teamMembers.slice(0, 10);
  const leader = teamMembers[0];

  return (
    <section className="section-dark py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(214,180,90,.18),transparent_28%),radial-gradient(circle_at_10%_90%,rgba(37,215,255,.12),transparent_24%)]" />
      <div className="container-soft relative z-10">
        <div className="mb-14 grid gap-8 lg:grid-cols-[.8fr_1.2fr] lg:items-end">
          <div>
            <span className="eyebrow"><UsersRound className="h-4 w-4" /> {t.team.badge}</span>
            <h2 className="mt-5 text-4xl font-black leading-tight text-white md:text-6xl">{isAr ? "الفريق ليس صوراً... إنه شبكة تنفيذ" : "Not just faces... an execution network"}</h2>
          </div>
          <p className="text-lg leading-9 text-white/65">{isAr ? "خبراء إدارة، تخليص، شحن، نقل، تصاريح، مشتريات، علاقات عامة، قانون، تسويق ومتابعة يعملون كوحدة تشغيل واحدة." : "Management, clearance, shipping, transport, permits, procurement, PR, legal, marketing, and follow-up experts operating as one unit."}</p>
        </div>

        {!showAll && (
          <div className="mb-8 grid gap-5 lg:grid-cols-[.85fr_1.15fr]">
            <div className="bento-card relative overflow-hidden p-0">
              <div className="relative h-[28rem]">
                <Image src={leader.img} alt={isAr ? leader.nameAr : leader.nameEn} fill className="object-cover object-top" unoptimized />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-dark via-primary-dark/25 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-secondary px-4 py-2 text-sm font-black text-primary-dark"><Crown className="h-4 w-4" /> {isAr ? "القيادة" : "Leadership"}</div>
                  <h3 className="text-3xl font-black text-white">{isAr ? leader.nameAr : leader.nameEn}</h3>
                  <p className="mt-1 font-bold text-secondary">{isAr ? leader.roleAr : leader.roleEn}</p>
                </div>
              </div>
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              {teamMembers.slice(1, 5).map((m) => <MemberMini key={m.id} m={m} isAr={isAr} />)}
            </div>
          </div>
        )}

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5">
          {displayed.slice(showAll ? 0 : 5).map((member) => (
            <article key={member.id} className="group overflow-hidden rounded-[2rem] border border-white/10 bg-white/[.06] shadow-2xl shadow-black/20 transition hover:-translate-y-1 hover:border-secondary/40">
              <div className="relative h-72 bg-white/5">
                <Image src={member.img} alt={isAr ? member.nameAr : member.nameEn} fill className="object-cover object-top transition duration-700 group-hover:scale-110" unoptimized />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-dark via-transparent to-transparent" />
                <div className="absolute right-3 top-3 rounded-full bg-black/40 px-3 py-1 text-xs font-black text-secondary backdrop-blur-xl">
                  {member.year}
                </div>
              </div>
              <div className="p-5">
                <h3 className="text-lg font-black text-white">{isAr ? member.nameAr : member.nameEn}</h3>
                <p className="mt-1 text-sm font-bold text-secondary">{isAr ? member.roleAr : member.roleEn}</p>
                <div className="mt-4 flex items-center gap-2 text-xs font-bold text-white/45"><CalendarDays className="h-4 w-4" /> {isAr ? "منذ" : "Since"} {member.year}</div>
              </div>
            </article>
          ))}
        </div>

        {!showAll && (
          <div className="mt-12 text-center">
            <Link href={`${p}/team`} className="btn-primary">{isAr ? "شاهد كل الفريق" : "View full team"} <Arrow className="h-5 w-5" /></Link>
          </div>
        )}
      </div>
    </section>
  );
}

function MemberMini({ m, isAr }: { m: (typeof teamMembers)[number]; isAr: boolean }) {
  return (
    <div className="bento-card flex items-center gap-4">
      <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl bg-white/10">
        <Image src={m.img} alt={isAr ? m.nameAr : m.nameEn} fill className="object-cover object-top" unoptimized />
      </div>
      <div>
        <BadgeCheck className="mb-2 h-5 w-5 text-secondary" />
        <h3 className="font-black text-white">{isAr ? m.nameAr : m.nameEn}</h3>
        <p className="mt-1 text-xs font-bold text-white/50">{isAr ? m.roleAr : m.roleEn}</p>
      </div>
    </div>
  );
}
