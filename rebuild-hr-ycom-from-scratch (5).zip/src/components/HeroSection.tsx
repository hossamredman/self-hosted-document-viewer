import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowRight, CheckCircle2, Container, Plane, Radar, Ship, ShieldCheck, Truck, WalletCards } from "lucide-react";
import type { Dictionary, Locale } from "@/lib/i18n";
import { LOGO_URL, SLOGAN_AR, SLOGAN_EN, statistics, APP_INFO } from "@/lib/data";

export default function HeroSection({ t, locale }: { t: Dictionary; locale: Locale }) {
  const isAr = locale === "ar";
  const p = isAr ? "" : "/en";
  const Arrow = isAr ? ArrowLeft : ArrowRight;

  const ops = [
    { icon: Ship, label: isAr ? "بحري" : "Sea", value: "FCL / LCL" },
    { icon: Plane, label: isAr ? "جوي" : "Air", value: "3-5 Days" },
    { icon: Truck, label: isAr ? "بري" : "Land", value: isAr ? "كل المحافظات" : "All Yemen" },
    { icon: WalletCards, label: isAr ? "شراء" : "Buying", value: "Amazon + Alibaba" },
  ];

  return (
    <section className="section-dark min-h-screen pt-32 md:pt-36">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(214,180,90,.22),transparent_35%),radial-gradient(circle_at_80%_10%,rgba(37,215,255,.18),transparent_30%),linear-gradient(135deg,#050914_0%,#0b1730_45%,#050914_100%)]" />
      <div className="absolute inset-0 opacity-[.07]" style={{ backgroundImage: "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg,#fff 1px, transparent 1px)", backgroundSize: "72px 72px" }} />
      <div className="absolute left-1/2 top-1/2 h-[52rem] w-[52rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/10" />
      <div className="absolute left-1/2 top-1/2 h-[38rem] w-[38rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-secondary/10" />

      <div className="container-soft relative z-10 pb-24">
        <div className="grid items-center gap-10 lg:grid-cols-[1.02fr_.98fr]">
          <div>
            <div className="eyebrow mb-6">
              <Radar className="h-4 w-4" />
              {isAr ? "ثقة بقدر المسؤولية | منصة لوجستية ذكية" : "Trust Equals Responsibility | Smart Logistics Platform"}
            </div>
            <h1 className="max-w-4xl text-5xl font-black leading-[1.12] text-white md:text-7xl">
              {isAr ? "طريقك الأوحد لكل شيء..." : "Your One Way for Everything..."}
              <span className="block bg-gradient-to-l from-secondary via-secondary-light to-accent bg-clip-text text-transparent">
                {isAr ? "مدعوم بالذكاء الاصطناعي" : "Powered by Artificial Intelligence"}
              </span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-9 text-white/70 md:text-xl">
              {isAr
                ? "نستخدم أحدث تقنيات الذكاء الاصطناعي في إدارة عمليات الشراء، المزايدات، الشحن بأنواعه، التخليص الجمركي، السفريات، التأمين، إنجاز المعاملات الحكومية، والتسليم النهائي. طريق واحد لكل شيء عبر تطبيق شحنات."
                : "We leverage cutting-edge AI technology to manage buying operations, auction bidding, all shipping types, customs clearance, travel services, insurance, government transactions, and final delivery. One way for everything through SHANAT app."}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href={`${p}/services`} className="btn-primary">
                {isAr ? "استكشف خدماتنا" : "Explore Our Services"} <Arrow className="h-5 w-5" />
              </Link>
              <Link href={`${p}/track`} className="btn-ghost">
                <Radar className="h-5 w-5" /> {t.nav.track}
              </Link>
            </div>

            <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                [`${statistics.yearsExperience}+`, isAr ? "سنة خبرة" : "Years"],
                [`${statistics.completedTransactions.toLocaleString()}+`, isAr ? "عملية" : "Operations"],
                [`${statistics.branches}+`, isAr ? "نقاط خدمة" : "Service Points"],
                [`${statistics.countries}+`, isAr ? "دولة" : "Countries"],
              ].map(([n, l]) => (
                <div key={l} className="glass rounded-3xl p-4">
                  <div className="text-3xl font-black text-secondary">{n}</div>
                  <div className="mt-1 text-xs font-bold text-white/55">{l}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative min-h-[36rem]">
            <div className="absolute inset-0 rounded-[3rem] bg-gradient-to-br from-secondary/20 via-accent/10 to-transparent blur-3xl animate-glow" />
            <div className="relative overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/[.06] p-5 shadow-2xl shadow-black/40 backdrop-blur-2xl">
              <div className="relative h-[31rem] overflow-hidden rounded-[2rem] bg-primary-dark">
                <Image src="https://images.pexels.com/photos/15346128/pexels-photo-15346128.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900" alt="logistics" fill className="object-cover opacity-55" unoptimized priority />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-dark via-primary-dark/35 to-transparent" />
                <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-accent/20 to-transparent animate-scan" />

                <div className="absolute right-5 top-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-black/30 p-3 backdrop-blur-xl">
                  <span className="relative grid h-14 w-14 place-items-center rounded-xl bg-white">
                    <Image src={LOGO_URL} alt="HR" fill className="object-contain p-1.5" unoptimized />
                  </span>
                  <div>
                    <div className="text-sm font-black text-white">HR-Y OS</div>
                    <div className="text-xs font-bold text-accent">LIVE OPERATIONS</div>
                  </div>
                </div>

                <div className="absolute bottom-5 left-5 right-5 grid gap-3 sm:grid-cols-2">
                  {ops.map((op) => {
                    const Icon = op.icon;
                    return (
                      <div key={op.label} className="rounded-2xl border border-white/10 bg-white/10 p-4 backdrop-blur-xl">
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <div className="text-sm font-black text-white">{op.label}</div>
                            <div className="mt-1 text-xs font-bold text-white/55">{op.value}</div>
                          </div>
                          <Icon className="h-7 w-7 text-secondary" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="absolute -left-4 top-16 hidden rounded-3xl border border-secondary/30 bg-secondary p-5 text-primary-dark shadow-2xl shadow-secondary/20 lg:block animate-floaty">
              <ShieldCheck className="mb-3 h-8 w-8" />
              <div className="text-sm font-black">{isAr ? "ضمان تسليم" : "Delivery Guarantee"}</div>
              <div className="text-xs font-bold opacity-70">{isAr ? "من الباب إلى الباب" : "Door to Door"}</div>
            </div>
            <div className="absolute -right-4 bottom-20 hidden rounded-3xl border border-white/10 bg-white/10 p-5 text-white shadow-2xl backdrop-blur-xl lg:block animate-floaty" style={{ animationDelay: "1.2s" }}>
              <Container className="mb-3 h-8 w-8 text-accent" />
              <div className="text-sm font-black">{isAr ? "حاويات / طرود" : "Containers / Parcels"}</div>
              <div className="mt-2 flex items-center gap-1 text-xs text-white/60"><CheckCircle2 className="h-3 w-3 text-secondary" /> {isAr ? "متابعة كاملة" : "Full tracking"}</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
