import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, Mail, MapPin, Phone, RadioTower } from "lucide-react";
import type { Dictionary, Locale } from "@/lib/i18n";
import { branches, LOGO_URL, SLOGAN_AR, SLOGAN_EN, ADDRESS_AR, ADDRESS_EN, services, shippingAgencies } from "@/lib/data";

export default function Footer({ t, locale }: { t: Dictionary; locale: Locale }) {
  const isAr = locale === "ar";
  const p = isAr ? "" : "/en";
  const links = [
    [p || "/", t.nav.home],
    [`${p}/services`, t.nav.services],
    [`${p}/branches`, isAr ? "الشبكة" : "Network"],
    [`${p}/team`, isAr ? "الفريق" : "Team"],
    [`${p}/partners`, isAr ? "الشركاء" : "Partners"],
    [`${p}/contact`, t.nav.contact],
  ];

  return (
    <footer className="section-dark border-t border-white/10 py-16">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_10%_0%,rgba(214,180,90,.15),transparent_28%)]" />
      <div className="container-soft relative z-10">
        <div className="grid gap-8 lg:grid-cols-[1.4fr_.8fr_.8fr_1fr]">
          <div className="rounded-[2rem] border border-white/10 bg-white/[.06] p-7">
            <div className="flex items-center gap-4">
              <div className="relative h-16 w-16 rounded-2xl bg-white p-2">
                <Image src={LOGO_URL} alt="HR" fill className="object-contain p-2" unoptimized />
              </div>
              <div>
                <h3 className="text-2xl font-black text-white">{isAr ? "حسام ردمان" : "Hussam Radman"}</h3>
                <p className="font-bold text-secondary">{isAr ? SLOGAN_AR : SLOGAN_EN}</p>
              </div>
            </div>
            <p className="mt-6 max-w-xl leading-8 text-white/60">{t.footer.desc}</p>
            <div className="mt-6 grid grid-cols-3 gap-3">
              <Mini value={`${branches.length}+`} label={isAr ? "فروع" : "Branches"} />
              <Mini value={`${services.length}+`} label={isAr ? "خدمات" : "Services"} />
              <Mini value={`${shippingAgencies.length}+`} label={isAr ? "وكالات" : "Agencies"} />
            </div>
          </div>

          <div className="pt-2">
            <h4 className="mb-5 text-lg font-black text-white">{t.footer.quickLinks}</h4>
            <div className="grid gap-3">
              {links.map(([href, label]) => (
                <Link key={href} href={href} className="group flex items-center justify-between rounded-2xl border border-white/10 bg-white/[.04] px-4 py-3 text-sm font-bold text-white/65 transition hover:border-secondary/40 hover:text-secondary">
                  {label}<ArrowUpRight className="h-4 w-4 opacity-0 transition group-hover:opacity-100" />
                </Link>
              ))}
            </div>
          </div>

          <div className="pt-2">
            <h4 className="mb-5 text-lg font-black text-white">{t.footer.ourServices}</h4>
            <div className="flex flex-wrap gap-2">
              {services.slice(0, 10).map((s) => (
                <Link key={s.id} href={`${p}/services`} className="rounded-full border border-white/10 bg-white/[.04] px-3 py-2 text-xs font-bold text-white/55 transition hover:border-secondary/50 hover:text-secondary">
                  {isAr ? s.titleAr : s.titleEn}
                </Link>
              ))}
            </div>
          </div>

          <div className="rounded-[2rem] border border-secondary/20 bg-secondary/10 p-7">
            <RadioTower className="mb-5 h-9 w-9 text-secondary" />
            <h4 className="text-xl font-black text-white">{isAr ? "تواصل مع غرفة العمليات" : "Contact Operations"}</h4>
            <div className="mt-5 grid gap-4 text-sm font-bold text-white/70">
              <a href="tel:+967778877011" className="flex items-center gap-3 hover:text-secondary"><Phone className="h-5 w-5 text-secondary" /><span dir="ltr">+967 778877011</span></a>
              <a href="mailto:info@hr-y.com" className="flex items-center gap-3 hover:text-secondary"><Mail className="h-5 w-5 text-secondary" />info@hr-y.com</a>
              <div className="flex items-center gap-3"><MapPin className="h-5 w-5 text-secondary" />{isAr ? ADDRESS_AR : ADDRESS_EN}</div>
            </div>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 text-sm font-bold text-white/40 md:flex-row">
          <p>© {new Date().getFullYear()} {isAr ? "حسام ردمان" : "Hussam Radman"}. {t.footer.rights}.</p>
          <Link href={t.nav.switchLangPath} className="text-secondary hover:text-secondary-light">{t.nav.switchLang}</Link>
        </div>
      </div>
    </footer>
  );
}

function Mini({ value, label }: { value: string; label: string }) {
  return <div className="rounded-2xl bg-white/5 p-3 text-center"><div className="text-2xl font-black text-secondary">{value}</div><div className="text-xs font-bold text-white/45">{label}</div></div>;
}
