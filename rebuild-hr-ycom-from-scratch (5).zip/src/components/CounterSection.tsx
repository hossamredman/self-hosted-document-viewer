"use client";
import { useEffect, useState, useRef } from "react";
import { Smile, Building2, Users, Award } from "lucide-react";
import type { Dictionary } from "@/lib/i18n";

function useCountUp(target: number, dur: number, start: boolean) {
  const [c, setC] = useState(0);
  useEffect(() => { if (!start) return; let s: number | null = null; let f: number; const a = (ts: number) => { if (!s) s = ts; const p = Math.min((ts - s) / dur, 1); setC(Math.floor(p * target)); if (p < 1) f = requestAnimationFrame(a); }; f = requestAnimationFrame(a); return () => cancelAnimationFrame(f); }, [target, dur, start]);
  return c;
}

function Card({ target, label, icon }: { target: number; label: string; icon: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(false);
  useEffect(() => { const o = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVis(true); }, { threshold: .5 }); if (ref.current) o.observe(ref.current); return () => o.disconnect(); }, []);
  const c = useCountUp(target, 2000, vis);
  return (
    <div ref={ref} className="text-center group">
      <div className="w-20 h-20 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4 text-secondary group-hover:bg-secondary group-hover:text-white transition-all duration-300 group-hover:scale-110">{icon}</div>
      <div className="text-4xl md:text-5xl font-black text-white mb-2">{c.toLocaleString()}+</div>
      <div className="text-white/70 font-medium">{label}</div>
    </div>
  );
}

export default function CounterSection({ t }: { t: Dictionary }) {
  const items = [
    { target: 5000, label: t.counter.clients, icon: <Smile className="w-8 h-8" /> },
    { target: 10, label: t.counter.branches, icon: <Building2 className="w-8 h-8" /> },
    { target: 120, label: t.counter.employees, icon: <Users className="w-8 h-8" /> },
    { target: 9845, label: t.counter.transactions, icon: <Award className="w-8 h-8" /> },
  ];
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-cover bg-center bg-fixed" style={{ backgroundImage: `url('https://images.pexels.com/photos/20581299/pexels-photo-20581299.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=2000')` }} />
      <div className="absolute inset-0 bg-gradient-to-r from-primary-dark/95 to-primary/90" />
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
          {items.map((i) => <Card key={i.label} {...i} />)}
        </div>
      </div>
    </section>
  );
}
