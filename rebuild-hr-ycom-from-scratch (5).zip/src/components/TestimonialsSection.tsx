"use client";
import { useEffect, useState } from "react";
import { Quote, Star } from "lucide-react";
import type { Dictionary } from "@/lib/i18n";
import { testimonials } from "@/lib/data";

export default function TestimonialsSection({ t, locale }: { t: Dictionary; locale: string }) {
  const isAr = locale === "ar";
  const [idx, setIdx] = useState(0);

  // Auto-rotate every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setIdx((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const cur = testimonials[idx];

  return (
    <section className="section-light py-24">
      <div className="container-soft relative z-10">
        <div className="mb-14 text-center">
          <span className="eyebrow border-primary/10 bg-primary/5 text-primary">{t.testimonials.badge}</span>
          <h2 className="mt-5 text-4xl font-black text-primary md:text-5xl">{t.testimonials.title}</h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-primary/60">{t.testimonials.subtitle}</p>
          <div className="mx-auto mt-4 h-1 w-20 rounded-full bg-secondary" />
        </div>

        <div className="mx-auto max-w-4xl">
          {/* Main card */}
          <div className="relative overflow-hidden rounded-[2.5rem] border border-primary/10 bg-white p-10 shadow-2xl shadow-primary/5 transition-all duration-700">
            <Quote className="absolute right-8 top-6 h-20 w-20 text-secondary/10" />

            {/* Stars */}
            <div className="mb-6 flex items-center gap-1">
              {Array.from({ length: cur.rating }).map((_, i) => (
                <Star key={i} className="h-6 w-6 fill-secondary text-secondary" />
              ))}
            </div>

            {/* Text with smooth transition */}
            <p key={idx} className="relative z-10 min-h-28 text-xl leading-10 text-primary/80">
              &ldquo;{isAr ? cur.textAr : cur.textEn}&rdquo;
            </p>

            <div className="mt-8 flex items-center gap-5">
              {/* Avatar circle with initials */}
              <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-primary to-primary-light shadow-lg">
                <span className="text-2xl font-black text-secondary">
                  {(isAr ? cur.nameAr : cur.nameEn).charAt(0)}
                </span>
              </div>
              <div>
                <h4 className="text-xl font-black text-primary">
                  {isAr ? cur.nameAr : cur.nameEn}
                </h4>
                <p className="mt-1 text-sm font-bold text-secondary">
                  {isAr ? cur.companyAr : cur.companyEn}
                </p>
              </div>

              {/* Counter */}
              <div className="mr-auto hidden rounded-2xl bg-primary/5 px-5 py-3 md:block">
                <div className="text-2xl font-black text-primary">{idx + 1}/{testimonials.length}</div>
              </div>
            </div>
          </div>

          {/* Navigation dots */}
          <div className="mt-8 flex items-center justify-center gap-3">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setIdx(i)}
                className={`cursor-pointer rounded-full transition-all duration-300 ${
                  i === idx ? "h-3 w-12 bg-secondary" : "h-3 w-3 bg-primary/15 hover:bg-secondary/50"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
