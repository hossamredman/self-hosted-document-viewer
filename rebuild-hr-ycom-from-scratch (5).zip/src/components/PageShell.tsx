import type { ReactNode } from "react";
import Header from "./Header";
import Footer from "./Footer";
import type { Dictionary, Locale } from "@/lib/i18n";
import Link from "next/link";

export function PageBanner({ title, breadcrumb, t, locale }: { title: string; breadcrumb: string; t: Dictionary; locale: Locale }) {
  const p = locale === "en" ? "/en" : "";
  return (
    <section className="relative py-32 md:py-40 overflow-hidden">
      <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('https://images.pexels.com/photos/36694994/pexels-photo-36694994.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=2000')` }} />
      <div className="absolute inset-0 bg-gradient-to-r from-primary-dark/95 via-primary/90 to-primary-dark/85" />
      <div className="container mx-auto px-4 relative z-10 text-center">
        <h1 className="text-4xl md:text-5xl font-black text-white mb-4">{title}</h1>
        <div className="flex items-center justify-center gap-3 text-white/80">
          <Link href={`${p}/`} className="hover:text-secondary transition-colors">{t.nav.home}</Link>
          <span className="text-secondary">›</span>
          <span className="text-secondary">{breadcrumb}</span>
        </div>
      </div>
    </section>
  );
}

export default function PageShell({ t, locale, children }: { t: Dictionary; locale: Locale; children: ReactNode }) {
  return (
    <>
      <Header t={t} locale={locale} />
      <main>{children}</main>
      <Footer t={t} locale={locale} />
    </>
  );
}
