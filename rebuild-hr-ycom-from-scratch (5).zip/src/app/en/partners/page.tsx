import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import { shippingAgencies, shoppingWebsites, auctionWebsites } from "@/lib/data";
import { Ship, Plane, ShoppingCart, Gavel, ExternalLink } from "lucide-react";
import Image from "next/image";
import CTASection from "@/components/CTASection";

export default function PartnersPageEn() {
  const t = getDictionary("en");
  return (
    <PageShell t={t} locale="en">
      <PageBanner title="Partners & Agencies" breadcrumb="Partners" t={t} locale="en" />
      
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">Shipping Agencies</span>
            <h2 className="section-title">Our Global Shipping Partners</h2>
            <p className="section-subtitle mt-4">We work with the largest sea and air shipping companies worldwide</p>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          <div className="mb-16">
            <h3 className="text-2xl font-bold text-primary mb-8 flex items-center gap-3"><Ship className="w-8 h-8 text-secondary" /> Sea Freight Companies</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {shippingAgencies.filter(a => a.type === "sea").map((agency) => (
                <div key={agency.id} className="bg-white p-6 rounded-2xl text-center shadow-lg hover:shadow-xl transition-all border border-gray-100 hover:border-secondary/30">
                  <div className="text-4xl mb-3">{agency.logo}</div>
                  <h4 className="font-bold text-primary text-sm">{agency.nameEn}</h4>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-primary mb-8 flex items-center gap-3"><Plane className="w-8 h-8 text-secondary" /> Air Freight Companies</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {shippingAgencies.filter(a => a.type === "air").map((agency) => (
                <div key={agency.id} className="bg-white p-6 rounded-2xl text-center shadow-lg hover:shadow-xl transition-all border border-gray-100 hover:border-secondary/30">
                  <div className="text-4xl mb-3">{agency.logo}</div>
                  <h4 className="font-bold text-primary text-sm">{agency.nameEn}</h4>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">Shopping Websites</span>
            <h2 className="section-title flex items-center justify-center gap-3"><ShoppingCart className="w-10 h-10 text-secondary" /> We Buy From Any Website</h2>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {shoppingWebsites.map((site) => (
              <div key={site.name} className="bg-gray-50 p-4 rounded-2xl text-center hover:bg-white hover:shadow-xl transition-all border border-transparent hover:border-secondary/30">
                <div className="w-12 h-12 mx-auto mb-3 relative rounded-xl overflow-hidden bg-white shadow">
                  <Image src={site.logo} alt={site.name} fill className="object-contain p-2" unoptimized />
                </div>
                <h4 className="font-bold text-primary text-sm">{site.name}</h4>
                <span className="inline-block mt-2 text-xs bg-secondary/10 text-secondary px-2 py-0.5 rounded-full">{site.region}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-primary-dark to-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">Auction Websites</span>
            <h2 className="text-3xl md:text-4xl font-bold mb-4 flex items-center justify-center gap-3"><Gavel className="w-10 h-10 text-secondary" /> We Bid On Any Auction</h2>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {auctionWebsites.map((site) => (
              <div key={site.name} className="bg-white/10 backdrop-blur-sm p-4 rounded-2xl text-center hover:bg-white/20 transition-all border border-white/10 hover:border-secondary/50">
                <div className="text-3xl mb-2">{site.logo}</div>
                <h4 className="font-bold text-white text-sm">{site.name}</h4>
                <span className="inline-block mt-2 text-xs bg-secondary text-white px-2 py-0.5 rounded-full">{site.region}</span>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <a href="/en/contact" className="btn-primary inline-flex items-center gap-2">
              Contact Us to Bid <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      <CTASection t={t} locale="en" />
    </PageShell>
  );
}
