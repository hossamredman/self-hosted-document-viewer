import type { Metadata } from "next";
import type { ReactNode } from "react";

export const metadata: Metadata = {
  title: "Hussam Radman | Customs Clearance & Shipping Services",
  description: "Hussam Radman for Customs Clearance and Shipping Services - Expert import and export solutions",
};

export default function EnLayout({ children }: { children: ReactNode }) {
  return (
    <div lang="en" dir="ltr" style={{ direction: "ltr", textAlign: "left" }}>
      {children}
    </div>
  );
}
