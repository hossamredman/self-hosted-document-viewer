"use client";
import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import { useState } from "react";
import { Search, Package, MapPin, Clock, CheckCircle } from "lucide-react";

export default function TrackPageEn() {
  const t = getDictionary("en");
  const [orderNum, setOrderNum] = useState("");
  const [searched, setSearched] = useState(false);
  return (
    <PageShell t={t} locale="en">
      <PageBanner title={t.track.title} breadcrumb={t.track.title} t={t} locale="en" />
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-primary/5 rounded-2xl flex items-center justify-center mx-auto mb-4 text-primary"><Package className="w-10 h-10" /></div>
                <h2 className="text-2xl font-bold text-primary">{t.track.title}</h2>
                <p className="text-gray-600 mt-2">{t.track.subtitle}</p>
              </div>
              <div className="flex gap-3">
                <input type="text" value={orderNum} onChange={(e) => setOrderNum(e.target.value)} placeholder={t.track.placeholder} className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all text-gray-700" />
                <button onClick={() => setSearched(true)} className="btn-primary !px-6 flex items-center gap-2"><Search className="w-5 h-5" />{t.track.button}</button>
              </div>
              {searched && (
                <div className="mt-8 p-6 bg-gray-50 rounded-xl border border-gray-200">
                  {orderNum ? (
                    <div className="space-y-4">
                      <h3 className="font-bold text-primary flex items-center gap-2"><Package className="w-5 h-5" />{t.track.status}: #{orderNum}</h3>
                      <div className="space-y-3">
                        {[{ icon: <CheckCircle className="w-5 h-5 text-green-500" />, text: "Order Received", time: "10:30 AM" },
                          { icon: <Clock className="w-5 h-5 text-secondary" />, text: "Processing", time: "2:00 PM" },
                          { icon: <MapPin className="w-5 h-5 text-gray-400" />, text: "In Transit", time: "---" },
                        ].map((s, i) => (
                          <div key={i} className="flex items-center gap-3 p-3 bg-white rounded-lg">{s.icon}<span className="flex-1 text-sm">{s.text}</span><span className="text-xs text-gray-400">{s.time}</span></div>
                        ))}
                      </div>
                    </div>
                  ) : <p className="text-gray-500 text-center">{t.track.notFound}</p>}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
