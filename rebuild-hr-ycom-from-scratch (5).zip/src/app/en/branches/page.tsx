import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import { branches, yemenPorts } from "@/lib/data";
import { MapPin, Phone, Ship, Plane, Truck, Building2, Anchor } from "lucide-react";
import CTASection from "@/components/CTASection";

export default function BranchesPageEn() {
  const t = getDictionary("en");
  return (
    <PageShell t={t} locale="en">
      <PageBanner title="Our Branches & Ports" breadcrumb="Branches" t={t} locale="en" />
      
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">Our Network</span>
            <h2 className="section-title">Our Branches in Yemen</h2>
            <p className="section-subtitle mt-4">We are present at all major ports to serve you best</p>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {branches.map((branch) => (
              <div key={branch.id} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 hover:border-secondary/30 group">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-4 group-hover:bg-secondary group-hover:text-white transition-all">
                  {branch.typeEn.includes("Port") ? <Truck className="w-7 h-7" /> : <Building2 className="w-7 h-7" />}
                </div>
                <h3 className="text-xl font-bold text-primary mb-2">{branch.cityEn}</h3>
                <p className="text-secondary text-sm font-medium mb-3">{branch.typeEn}</p>
                <div className="space-y-2 text-gray-600 text-sm">
                  <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-gray-400" />{branch.address}</div>
                  <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-gray-400" /><span dir="ltr">{branch.phone}</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="section-title flex items-center justify-center gap-3"><Anchor className="w-10 h-10 text-secondary" /> Sea Ports</h2>
          </div>
          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4">
            {yemenPorts.sea.map((port) => (
              <div key={port.nameEn} className={`p-6 rounded-2xl text-center transition-all hover:scale-105 ${port.type === "main" ? "bg-primary text-white" : "bg-gray-100 text-primary"}`}>
                <Ship className={`w-8 h-8 mx-auto mb-3 ${port.type === "main" ? "text-secondary" : "text-primary"}`} />
                <h3 className="font-bold">{port.nameEn}</h3>
                {port.type === "main" && <span className="inline-block mt-2 text-xs bg-secondary px-2 py-1 rounded-full">Main</span>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="section-title flex items-center justify-center gap-3"><Truck className="w-10 h-10 text-secondary" /> Land Borders</h2>
          </div>
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-4">
            {yemenPorts.land.map((port) => (
              <div key={port.nameEn} className="bg-white p-6 rounded-2xl text-center shadow-lg hover:shadow-xl transition-all border border-gray-100">
                <Truck className="w-8 h-8 mx-auto mb-3 text-primary" />
                <h3 className="font-bold text-primary">{port.nameEn}</h3>
                <span className="inline-block mt-2 text-xs bg-secondary/10 text-secondary px-2 py-1 rounded-full">{port.country}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="section-title flex items-center justify-center gap-3"><Plane className="w-10 h-10 text-secondary" /> International Airports</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {yemenPorts.air.map((port) => (
              <div key={port.nameEn} className="bg-gradient-to-br from-primary to-primary-dark p-8 rounded-2xl text-center text-white shadow-xl hover:scale-105 transition-transform">
                <Plane className="w-12 h-12 mx-auto mb-4 text-secondary" />
                <h3 className="font-bold text-lg">{port.nameEn}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection t={t} locale="en" />
    </PageShell>
  );
}
