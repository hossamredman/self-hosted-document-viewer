import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import AboutSection from "@/components/AboutSection";
import TeamSection from "@/components/TeamSection";
import CounterSection from "@/components/CounterSection";
import CTASection from "@/components/CTASection";

export default function AboutPageEn() {
  const t = getDictionary("en");
  return (
    <PageShell t={t} locale="en">
      <PageBanner title={t.nav.about} breadcrumb={t.nav.about} t={t} locale="en" />
      <AboutSection t={t} />
      <CounterSection t={t} />
      <TeamSection t={t} locale="en" />
      <CTASection t={t} locale="en" />
    </PageShell>
  );
}
