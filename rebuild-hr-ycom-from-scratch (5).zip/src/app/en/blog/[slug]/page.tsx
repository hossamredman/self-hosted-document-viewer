import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import Link from "next/link";

const posts: Record<string, { title: string; content: string; img: string }> = {
  "importance-of-customs-clearance": { title: "Importance of Customs Clearance in International Trade", content: "Customs clearance is one of the most important logistics operations ensuring smooth movement of goods across international borders.\n\nIt involves legal and administrative procedures required for goods to enter or leave a country.\n\nAt Hussam Radman, we have over 15 years of customs clearance experience.", img: "https://images.pexels.com/photos/20581299/pexels-photo-20581299.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200" },
  "guide-to-importing-goods": { title: "Your Complete Guide to Importing Goods to Yemen", content: "Importing goods to Yemen requires deep understanding of customs procedures.\n\nRequired documents: commercial invoice, bill of lading, certificate of origin, packing list.\n\nContact us for a free import consultation.", img: "https://images.pexels.com/photos/24246926/pexels-photo-24246926.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200" },
  "how-to-choose-shipping-company": { title: "How to Choose the Right Shipping Company", content: "Choosing the right shipping company is a crucial decision for import/export success.\n\nLook for experience, reputation, geographic coverage, and competitive prices.\n\nAt Hussam Radman, we offer all shipping services at the best prices.", img: "https://images.pexels.com/photos/33537946/pexels-photo-33537946.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200" },
};

type PageProps = { params: Promise<{ slug: string }> };

export default async function BlogPostPageEn({ params }: PageProps) {
  const { slug } = await params;
  const t = getDictionary("en");
  const post = posts[slug] || { title: "Article", content: "Content not available.", img: "https://images.pexels.com/photos/20581299/pexels-photo-20581299.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200" };
  return (
    <PageShell t={t} locale="en">
      <PageBanner title={post.title} breadcrumb={t.blog.badge} t={t} locale="en" />
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="rounded-3xl overflow-hidden shadow-xl mb-10"><img src={post.img} alt={post.title} className="w-full h-[400px] object-cover" /></div>
          <article className="bg-white rounded-2xl p-8 md:p-12 shadow-lg border border-gray-100">
            <div className="text-gray-700 leading-relaxed whitespace-pre-line text-lg">{post.content}</div>
          </article>
          <div className="mt-10 text-center"><Link href="/en/blog" className="btn-primary">{t.blog.backToBlog}</Link></div>
        </div>
      </section>
    </PageShell>
  );
}
