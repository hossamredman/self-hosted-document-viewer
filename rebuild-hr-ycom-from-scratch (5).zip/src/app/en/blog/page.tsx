import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import BlogSection from "@/components/BlogSection";

export default function BlogPageEn() {
  const t = getDictionary("en");
  return (
    <PageShell t={t} locale="en">
      <PageBanner title={t.nav.blog} breadcrumb={t.nav.blog} t={t} locale="en" />
      <BlogSection t={t} locale="en" />
    </PageShell>
  );
}
