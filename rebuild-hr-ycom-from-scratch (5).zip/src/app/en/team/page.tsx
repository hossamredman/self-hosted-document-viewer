import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import TeamSection from "@/components/TeamSection";
import CTASection from "@/components/CTASection";

export default function TeamPageEn() {
  const t = getDictionary("en");
  return (
    <PageShell t={t} locale="en">
      <PageBanner title="Our Team" breadcrumb="Team" t={t} locale="en" />
      <TeamSection t={t} locale="en" showAll />
      <CTASection t={t} locale="en" />
    </PageShell>
  );
}
