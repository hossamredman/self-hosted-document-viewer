import { getDictionary } from "@/lib/i18n";
import PageShell from "@/components/PageShell";
import HeroSection from "@/components/HeroSection";
import StepsSection from "@/components/StepsSection";
import AboutSection from "@/components/AboutSection";
import ServicesSection from "@/components/ServicesSection";
import CommandCenterSection from "@/components/CommandCenterSection";
import TeamSection from "@/components/TeamSection";
import CounterSection from "@/components/CounterSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import BlogSection from "@/components/BlogSection";
import CTASection from "@/components/CTASection";

export default function HomePageEn() {
  const t = getDictionary("en");
  return (
    <PageShell t={t} locale="en">
      <HeroSection t={t} locale="en" />
      <CommandCenterSection locale="en" />
      <StepsSection t={t} />
      <AboutSection t={t} />
      <ServicesSection t={t} locale="en" />
      <TeamSection t={t} locale="en" />
      <CounterSection t={t} />
      <TestimonialsSection t={t} locale="en" />
      <BlogSection t={t} locale="en" />
      <CTASection t={t} locale="en" />
    </PageShell>
  );
}
