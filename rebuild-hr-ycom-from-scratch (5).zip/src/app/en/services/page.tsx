import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import ServicesSection from "@/components/ServicesSection";
import ServicesDetails from "@/components/ServicesDetails";
import CTASection from "@/components/CTASection";

export default function ServicesPageEn() {
  const t = getDictionary("en");
  return (
    <PageShell t={t} locale="en">
      <PageBanner title={t.nav.services} breadcrumb={t.nav.services} t={t} locale="en" />
      <ServicesSection t={t} locale="en" showAll />
      <ServicesDetails locale="en" />
      <CTASection t={t} locale="en" />
    </PageShell>
  );
}
