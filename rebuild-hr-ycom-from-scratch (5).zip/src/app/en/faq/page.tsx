import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import CTASection from "@/components/CTASection";
import FAQAccordion from "@/components/FAQAccordion";

const faqsEn = [
  { q: "What logistics services do you provide?", a: "We offer customs clearance, sea/air/land shipping, warehousing, customs consulting, buying from global websites, and auction bidding services." },
  { q: "What customs clearance services are available?", a: "We facilitate import/export procedures, goods classification, customs documentation, customs guarantee processing, and bottleneck resolution." },
  { q: "How are import costs calculated in advance?", a: "We provide pre-calculation including: customs duties, taxes, shipping/insurance costs, agency and clearance fees, and other administrative costs." },
  { q: "Do you offer buying from international websites?", a: "Yes, we buy from Amazon, Alibaba, Shein, Temu, Noon and more with direct shipping to Yemen." },
  { q: "Do you offer auction bidding services?", a: "Yes, we bid and buy from global auction sites like Copart, IAA, and car auctions across USA, Europe, Japan, and the Gulf." },
];

export default function FAQPageEn() {
  const t = getDictionary("en");
  return (
    <PageShell t={t} locale="en">
      <PageBanner title={t.nav.faq} breadcrumb={t.nav.faq} t={t} locale="en" />
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-4">
            {faqsEn.map((f) => <FAQAccordion key={f.q} question={f.q} answer={f.a} />)}
          </div>
        </div>
      </section>
      <CTASection t={t} locale="en" />
    </PageShell>
  );
}
