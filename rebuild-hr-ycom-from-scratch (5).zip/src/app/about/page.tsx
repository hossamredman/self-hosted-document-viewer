import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import AboutSection from "@/components/AboutSection";
import TeamSection from "@/components/TeamSection";
import CounterSection from "@/components/CounterSection";
import CTASection from "@/components/CTASection";

export default function AboutPage() {
  const t = getDictionary("ar");
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title={t.nav.about} breadcrumb={t.nav.about} t={t} locale="ar" />
      <AboutSection t={t} />
      <CounterSection t={t} />
      <TeamSection t={t} locale="ar" />
      <CTASection t={t} locale="ar" />
    </PageShell>
  );
}
