import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Toaster } from "react-hot-toast";

export const metadata: Metadata = {
  title: "حسام ردمان | للتخليص الجمركي وخدمات الشحن",
  description: "شركة حسام ردمان للتخليص الجمركي وخدمات الشحن - خبرة متميزة في التخليص الجمركي وحلول الاستيراد والتصدير",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-light text-slate-900 antialiased" style={{ fontFamily: "'Cairo', sans-serif" }}>
        <Toaster position="top-center" toastOptions={{ duration: 4000, style: { borderRadius: '12px', padding: '16px', fontFamily: "'Cairo', sans-serif" } }} />
        {children}
      </body>
    </html>
  );
}
