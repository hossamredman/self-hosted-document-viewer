import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import Link from "next/link";

const posts: Record<string, { titleAr: string; titleEn: string; contentAr: string; contentEn: string; img: string }> = {
  "importance-of-customs-clearance": { titleAr: "أهمية التخليص الجمركي في التجارة الدولية", titleEn: "Importance of Customs Clearance", contentAr: "يعد التخليص الجمركي من أهم العمليات اللوجستية التي تضمن سلاسة حركة البضائع عبر الحدود الدولية.\n\nالتخليص الجمركي هو مجموعة من الإجراءات القانونية والإدارية اللازمة لدخول البضائع أو خروجها من بلد ما.\n\nنحن في حسام ردمان نتمتع بخبرة تتجاوز 15 عاماً في مجال التخليص الجمركي.", contentEn: "Customs clearance is one of the most important logistics operations ensuring smooth movement of goods across borders.\n\nIt involves legal and administrative procedures for goods entering or leaving a country.\n\nAt Hussam Radman, we have over 15 years of experience in customs clearance.", img: "https://images.pexels.com/photos/20581299/pexels-photo-20581299.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200" },
  "guide-to-importing-goods": { titleAr: "دليلك الشامل لاستيراد البضائع إلى اليمن", titleEn: "Guide to Importing Goods to Yemen", contentAr: "استيراد البضائع إلى الجمهورية اليمنية يتطلب فهماً عميقاً للإجراءات والمتطلبات الجمركية.\n\nالمستندات المطلوبة تشمل: فاتورة تجارية، بوليصة شحن، شهادة المنشأ، بيان العبوة.\n\nتواصل معنا للحصول على استشارة مجانية حول عملية الاستيراد.", contentEn: "Importing goods to Yemen requires a deep understanding of customs procedures and requirements.\n\nRequired documents include: commercial invoice, bill of lading, certificate of origin, packing list.\n\nContact us for a free consultation on the import process.", img: "https://images.pexels.com/photos/24246926/pexels-photo-24246926.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200" },
  "how-to-choose-shipping-company": { titleAr: "كيف تختار شركة الشحن المناسبة", titleEn: "How to Choose a Shipping Company", contentAr: "اختيار شركة الشحن المناسبة يعد قراراً حاسماً يؤثر على نجاح عمليات الاستيراد والتصدير.\n\nابحث عن شركة ذات خبرة طويلة وسمعة جيدة وتغطية جغرافية واسعة وأسعار تنافسية.\n\nنحن في حسام ردمان نقدم جميع أنواع خدمات الشحن بأفضل الأسعار.", contentEn: "Choosing the right shipping company is a crucial decision that affects import/export success.\n\nLook for a company with long experience, good reputation, wide coverage, and competitive prices.\n\nAt Hussam Radman, we offer all types of shipping services at the best prices.", img: "https://images.pexels.com/photos/33537946/pexels-photo-33537946.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200" },
};

type PageProps = { params: Promise<{ slug: string }> };

export default async function BlogPostPage({ params }: PageProps) {
  const { slug } = await params;
  const t = getDictionary("ar");
  const post = posts[slug] || { titleAr: "مقال", titleEn: "Article", contentAr: "محتوى غير متوفر", contentEn: "Content not available", img: "https://images.pexels.com/photos/20581299/pexels-photo-20581299.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200" };
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title={post.titleAr} breadcrumb={t.blog.badge} t={t} locale="ar" />
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="rounded-3xl overflow-hidden shadow-xl mb-10"><img src={post.img} alt={post.titleAr} className="w-full h-[400px] object-cover" /></div>
          <article className="bg-white rounded-2xl p-8 md:p-12 shadow-lg border border-gray-100">
            <div className="text-gray-700 leading-relaxed whitespace-pre-line text-lg">{post.contentAr}</div>
          </article>
          <div className="mt-10 text-center"><Link href="/blog" className="btn-primary inline-flex items-center gap-2">{t.blog.backToBlog}</Link></div>
        </div>
      </section>
    </PageShell>
  );
}
