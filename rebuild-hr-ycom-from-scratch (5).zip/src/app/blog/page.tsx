import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import BlogSection from "@/components/BlogSection";

export default function BlogPage() {
  const t = getDictionary("ar");
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title={t.nav.blog} breadcrumb={t.nav.blog} t={t} locale="ar" />
      <BlogSection t={t} locale="ar" />
    </PageShell>
  );
}
