import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import { branches, yemenPorts } from "@/lib/data";
import { MapPin, Phone, Ship, Plane, Truck, Building2, Anchor } from "lucide-react";
import CTASection from "@/components/CTASection";

export default function BranchesPage() {
  const t = getDictionary("ar");
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title="فروعنا ومنافذنا" breadcrumb="الفروع" t={t} locale="ar" />
      
      {/* Branches Grid */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">شبكة فروعنا</span>
            <h2 className="section-title">فروعنا في الجمهورية اليمنية</h2>
            <p className="section-subtitle mt-4">نتواجد في جميع المنافذ الرئيسية لخدمتكم بأفضل شكل</p>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {branches.map((branch) => (
              <div key={branch.id} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 hover:border-secondary/30 group">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-4 group-hover:bg-secondary group-hover:text-white transition-all">
                  {branch.typeAr.includes("منفذ") ? <Truck className="w-7 h-7" /> : <Building2 className="w-7 h-7" />}
                </div>
                <h3 className="text-xl font-bold text-primary mb-2">{branch.cityAr}</h3>
                <p className="text-secondary text-sm font-medium mb-3">{branch.typeAr}</p>
                <div className="space-y-2 text-gray-600 text-sm">
                  <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-gray-400" />{branch.address}</div>
                  <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-gray-400" /><span dir="ltr">{branch.phone}</span></div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  {branch.services.map((s) => (
                    <span key={s} className="text-xs bg-primary/5 text-primary px-2 py-1 rounded-full">
                      {s === "customs" ? "تخليص" : s === "shipping" ? "شحن" : s === "seaport" ? "ميناء" : s === "landport" ? "منفذ بري" : s}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sea Ports */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">الموانئ البحرية</span>
            <h2 className="section-title flex items-center justify-center gap-3"><Anchor className="w-10 h-10 text-secondary" /> موانئ اليمن البحرية</h2>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>
          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4">
            {yemenPorts.sea.map((port) => (
              <div key={port.nameAr} className={`p-6 rounded-2xl text-center transition-all hover:scale-105 ${port.type === "main" ? "bg-primary text-white" : "bg-gray-100 text-primary"}`}>
                <Ship className={`w-8 h-8 mx-auto mb-3 ${port.type === "main" ? "text-secondary" : "text-primary"}`} />
                <h3 className="font-bold">{port.nameAr}</h3>
                <p className={`text-xs mt-1 ${port.type === "main" ? "text-white/70" : "text-gray-500"}`}>{port.nameEn}</p>
                {port.type === "main" && <span className="inline-block mt-2 text-xs bg-secondary px-2 py-1 rounded-full">رئيسي</span>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Land Ports */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">المنافذ البرية</span>
            <h2 className="section-title flex items-center justify-center gap-3"><Truck className="w-10 h-10 text-secondary" /> المنافذ البرية</h2>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-4">
            {yemenPorts.land.map((port) => (
              <div key={port.nameAr} className="bg-white p-6 rounded-2xl text-center shadow-lg hover:shadow-xl transition-all border border-gray-100 hover:border-secondary/30">
                <Truck className="w-8 h-8 mx-auto mb-3 text-primary" />
                <h3 className="font-bold text-primary">{port.nameAr}</h3>
                <p className="text-xs text-gray-500 mt-1">{port.nameEn}</p>
                <span className="inline-block mt-2 text-xs bg-secondary/10 text-secondary px-2 py-1 rounded-full">{port.country === "Saudi Arabia" ? "السعودية" : "عُمان"}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Airports */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">المطارات</span>
            <h2 className="section-title flex items-center justify-center gap-3"><Plane className="w-10 h-10 text-secondary" /> المطارات الدولية</h2>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {yemenPorts.air.map((port) => (
              <div key={port.nameAr} className="bg-gradient-to-br from-primary to-primary-dark p-8 rounded-2xl text-center text-white shadow-xl hover:scale-105 transition-transform">
                <Plane className="w-12 h-12 mx-auto mb-4 text-secondary" />
                <h3 className="font-bold text-lg">{port.nameAr}</h3>
                <p className="text-white/70 text-sm mt-2">{port.nameEn}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection t={t} locale="ar" />
    </PageShell>
  );
}
