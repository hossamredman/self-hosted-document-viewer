import { getDictionary } from "@/lib/i18n";
import PageShell from "@/components/PageShell";
import HeroSection from "@/components/HeroSection";
import StepsSection from "@/components/StepsSection";
import AboutSection from "@/components/AboutSection";
import ServicesSection from "@/components/ServicesSection";
import CommandCenterSection from "@/components/CommandCenterSection";
import TeamSection from "@/components/TeamSection";
import CounterSection from "@/components/CounterSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import BlogSection from "@/components/BlogSection";
import CTASection from "@/components/CTASection";

export default function HomePage() {
  const t = getDictionary("ar");
  return (
    <PageShell t={t} locale="ar">
      <HeroSection t={t} locale="ar" />
      <CommandCenterSection locale="ar" />
      <StepsSection t={t} />
      <AboutSection t={t} />
      <ServicesSection t={t} locale="ar" />
      <TeamSection t={t} locale="ar" />
      <CounterSection t={t} />
      <TestimonialsSection t={t} locale="ar" />
      <BlogSection t={t} locale="ar" />
      <CTASection t={t} locale="ar" />
    </PageShell>
  );
}
