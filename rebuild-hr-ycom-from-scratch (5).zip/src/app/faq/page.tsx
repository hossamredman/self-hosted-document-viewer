import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import CTASection from "@/components/CTASection";
import FAQAccordion from "@/components/FAQAccordion";

const faqsAr = [
  { q: "ما هي الخدمات اللوجستية التي تقدمونها؟", a: "نقدم مجموعة شاملة من الخدمات تشمل التخليص الجمركي، الشحن البحري والجوي والبري، التخزين، الاستشارات الجمركية، الشراء من المواقع العالمية، والمزايدة من مواقع المزادات." },
  { q: "ما هي خدمات التخليص الجمركي المتاحة؟", a: "نقوم بتسهيل إجراءات استيراد وتصدير البضائع، تصنيف البضائع وتحديد التعريفة الجمركية، تجهيز الوثائق الجمركية، معالجة الضمانات الجمركية، وتسوية الاختناقات." },
  { q: "كيف يتم احتساب تكاليف الاستيراد مسبقاً؟", a: "نقدم خدمات الاحتساب المسبق تشمل: رسوم الجمارك، الضرائب والرسوم الأخرى، تكاليف الشحن والتأمين، رسوم الوكالة والتخليص الجمركي." },
  { q: "هل تقدمون خدمات الشراء من المواقع العالمية؟", a: "نعم، نقدم خدمة الشراء من مواقع مثل أمازون، علي بابا، شي إن، تيمو، نون وغيرها مع الشحن المباشر إلى اليمن." },
  { q: "هل تقدمون خدمات المزايدة من مواقع المزادات؟", a: "نعم، نقدم خدمة المزايدة والشراء من مواقع المزادات العالمية مثل كوبارت، IAA، ومزادات السيارات في أمريكا وأوروبا واليابان والخليج." },
];

export default function FAQPage() {
  const t = getDictionary("ar");
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title={t.nav.faq} breadcrumb={t.nav.faq} t={t} locale="ar" />
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-4">
            {faqsAr.map((f) => <FAQAccordion key={f.q} question={f.q} answer={f.a} />)}
          </div>
        </div>
      </section>
      <CTASection t={t} locale="ar" />
    </PageShell>
  );
}
