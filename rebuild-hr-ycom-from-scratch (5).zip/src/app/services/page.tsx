import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import ServicesSection from "@/components/ServicesSection";
import ServicesDetails from "@/components/ServicesDetails";
import CTASection from "@/components/CTASection";

export default function ServicesPage() {
  const t = getDictionary("ar");
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title={t.nav.services} breadcrumb={t.nav.services} t={t} locale="ar" />
      <ServicesSection t={t} locale="ar" showAll />
      <ServicesDetails locale="ar" />
      <CTASection t={t} locale="ar" />
    </PageShell>
  );
}
