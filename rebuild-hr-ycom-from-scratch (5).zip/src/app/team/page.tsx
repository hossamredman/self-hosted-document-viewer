import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import TeamSection from "@/components/TeamSection";
import CTASection from "@/components/CTASection";

export default function TeamPage() {
  const t = getDictionary("ar");
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title="فريق العمل" breadcrumb="الفريق" t={t} locale="ar" />
      <TeamSection t={t} locale="ar" showAll />
      <CTASection t={t} locale="ar" />
    </PageShell>
  );
}
