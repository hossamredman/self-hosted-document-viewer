import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import ContactForm from "@/components/ContactForm";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function ContactPage() {
  const t = getDictionary("ar");
  const info = [
    { title: t.contact.address, details: [t.contact.yemen, t.contact.cities], icon: <MapPin className="w-6 h-6" /> },
    { title: t.contact.phone, details: ["+967 778877011"], icon: <Phone className="w-6 h-6" /> },
    { title: t.contact.email, details: ["info@hr-y.com"], icon: <Mail className="w-6 h-6" /> },
    { title: t.contact.hours, details: [t.contact.workDays, t.contact.workTime], icon: <Clock className="w-6 h-6" /> },
  ];
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title={t.nav.contact} breadcrumb={t.nav.contact} t={t} locale="ar" />
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">{t.contact.badge}</span>
            <h2 className="section-title">{t.contact.title}</h2>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>
          <div className="grid lg:grid-cols-3 gap-10">
            <div className="space-y-6">
              {info.map((i) => (
                <div key={i.title} className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover:border-secondary/30 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 bg-primary/5 rounded-xl flex items-center justify-center text-primary shrink-0 group-hover:bg-secondary group-hover:text-white transition-all duration-300">{i.icon}</div>
                    <div><h3 className="text-lg font-bold text-primary mb-2">{i.title}</h3>{i.details.map((d) => <p key={d} className="text-gray-600 text-sm">{d}</p>)}</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="lg:col-span-2">
              <div className="bg-white rounded-2xl p-8 md:p-10 shadow-lg border border-gray-100">
                <h3 className="text-2xl font-bold text-primary mb-6">{t.contact.formTitle}</h3>
                <ContactForm t={t} />
              </div>
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
