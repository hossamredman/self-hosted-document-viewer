import { getDictionary } from "@/lib/i18n";
import PageShell, { PageBanner } from "@/components/PageShell";
import { shippingAgencies, shoppingWebsites, auctionWebsites } from "@/lib/data";
import { Ship, Plane, ShoppingCart, Gavel, ExternalLink } from "lucide-react";
import Image from "next/image";
import CTASection from "@/components/CTASection";

export default function PartnersPage() {
  const t = getDictionary("ar");
  return (
    <PageShell t={t} locale="ar">
      <PageBanner title="شركاؤنا ووكالاتنا" breadcrumb="الشركاء" t={t} locale="ar" />
      
      {/* Shipping Agencies */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">وكالات الشحن</span>
            <h2 className="section-title">شركاؤنا في الشحن العالمي</h2>
            <p className="section-subtitle mt-4">نتعامل مع أكبر شركات الشحن البحري والجوي في العالم</p>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          {/* Sea Shipping */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-primary mb-8 flex items-center gap-3"><Ship className="w-8 h-8 text-secondary" /> شركات الشحن البحري</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {shippingAgencies.filter(a => a.type === "sea").map((agency) => (
                <div key={agency.id} className="bg-white p-6 rounded-2xl text-center shadow-lg hover:shadow-xl transition-all border border-gray-100 hover:border-secondary/30 group">
                  <div className="text-4xl mb-3">{agency.logo}</div>
                  <h4 className="font-bold text-primary text-sm">{agency.nameAr}</h4>
                  <p className="text-xs text-gray-500 mt-1">{agency.nameEn}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Air Shipping */}
          <div>
            <h3 className="text-2xl font-bold text-primary mb-8 flex items-center gap-3"><Plane className="w-8 h-8 text-secondary" /> شركات الشحن الجوي</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {shippingAgencies.filter(a => a.type === "air").map((agency) => (
                <div key={agency.id} className="bg-white p-6 rounded-2xl text-center shadow-lg hover:shadow-xl transition-all border border-gray-100 hover:border-secondary/30 group">
                  <div className="text-4xl mb-3">{agency.logo}</div>
                  <h4 className="font-bold text-primary text-sm">{agency.nameAr}</h4>
                  <p className="text-xs text-gray-500 mt-1">{agency.nameEn}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Shopping Websites */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">مواقع التسوق</span>
            <h2 className="section-title flex items-center justify-center gap-3"><ShoppingCart className="w-10 h-10 text-secondary" /> نشتري لك من أي موقع</h2>
            <p className="section-subtitle mt-4">نقدم خدمة الشراء والشحن من جميع المواقع العالمية الكبرى</p>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {shoppingWebsites.map((site) => (
              <div key={site.name} className="bg-gray-50 p-4 rounded-2xl text-center hover:bg-white hover:shadow-xl transition-all border border-transparent hover:border-secondary/30 group cursor-pointer">
                <div className="w-12 h-12 mx-auto mb-3 relative rounded-xl overflow-hidden bg-white shadow">
                  <Image src={site.logo} alt={site.name} fill className="object-contain p-2" unoptimized />
                </div>
                <h4 className="font-bold text-primary text-sm">{site.nameAr}</h4>
                <p className="text-xs text-gray-500 mt-1">{site.name}</p>
                <span className="inline-block mt-2 text-xs bg-secondary/10 text-secondary px-2 py-0.5 rounded-full">{site.region}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Auction Websites */}
      <section className="py-20 bg-gradient-to-br from-primary-dark to-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold text-sm tracking-wider uppercase mb-4 block">مواقع المزادات</span>
            <h2 className="text-3xl md:text-4xl font-bold mb-4 flex items-center justify-center gap-3"><Gavel className="w-10 h-10 text-secondary" /> نزايد لك في أي مزاد</h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto">نشارك في مزادات السيارات والمعدات حول العالم نيابة عنك</p>
            <div className="w-20 h-1 bg-secondary mx-auto mt-4 rounded-full" />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {auctionWebsites.map((site) => (
              <div key={site.name} className="bg-white/10 backdrop-blur-sm p-4 rounded-2xl text-center hover:bg-white/20 transition-all border border-white/10 hover:border-secondary/50 group cursor-pointer">
                <div className="text-3xl mb-2">{site.logo}</div>
                <h4 className="font-bold text-white text-sm">{site.nameAr}</h4>
                <p className="text-xs text-white/60 mt-1">{site.name}</p>
                <span className="inline-block mt-2 text-xs bg-secondary text-white px-2 py-0.5 rounded-full">{site.region}</span>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-white/80 mb-4">وغيرها الكثير من مواقع المزادات حول العالم</p>
            <a href="/contact" className="btn-primary inline-flex items-center gap-2">
              تواصل معنا للمزايدة <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      <CTASection t={t} locale="ar" />
    </PageShell>
  );
}
