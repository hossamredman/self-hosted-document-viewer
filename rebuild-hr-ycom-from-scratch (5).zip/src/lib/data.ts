// Company Logo - الشعار الصحيح
export const LOGO_URL = "https://hr-y.com/assets/images/logoIcon/logo-1.png";
export const LOGO_DARK_URL = "https://hr-y.com/assets/images/logoIcon/logo.png";
export const LOGO_ICON_URL = "https://hr-y.com/assets/images/logoIcon/favicon.png";

// Slogan
export const SLOGAN_AR = "ثقة بقدر المسؤولية";
export const SLOGAN_EN = "Trust Equals Responsibility";

// Company Address
export const ADDRESS_AR = "الجمهورية اليمنية، صنعاء، جوار وزارة الإعلام";
export const ADDRESS_EN = "Republic of Yemen, Sana'a, Near Ministry of Information";

// Service Images from hr-y.com
export const SERVICE_IMAGES = {
  buying: "https://hr-y.com/assets/images/frontend/service/662bdc1442dd81714150420.png",
  landTransport: "https://hr-y.com/assets/images/frontend/service/662be1ae7d7131714151854.png",
  customsClearance: "https://hr-y.com/assets/images/frontend/service/662be8870964b1714153607.png",
  costCalc: "https://hr-y.com/assets/images/frontend/service/662bedfb2d17e1714155003.png",
  containerShipping: "https://hr-y.com/assets/images/frontend/service/662be6cd227521714153165.png",
  parcelShipping: "https://hr-y.com/assets/images/frontend/service/662bea9ee38561714154142.png",
  consulting: "https://hr-y.com/assets/images/frontend/service/662bf09a7d7551714155674.png",
  taxCalc: "https://hr-y.com/assets/images/frontend/service/65cd03019c5731707934465.png",
  permits: "https://hr-y.com/assets/images/frontend/service/65cd049a730f41707934874.png",
  servicesBg: "https://hr-y.com/assets/images/frontend/service/632ffd40069361664089408.jpg",
};

// Original site images
export const SITE_IMAGES = {
  aboutImage: "https://hr-y.com/assets/images/frontend/about/6585c6d8417551703266008.png",
  faqImage: "https://hr-y.com/assets/images/frontend/faq/65845fe0d35b61703174112.png",
  counterBg: "https://hr-y.com/assets/images/frontend/counter/632ffafb46e611664088827.jpg",
  clientBg: "https://hr-y.com/assets/images/frontend/client/632ff9f2c8b171664088562.jpg",
  blog1: "https://hr-y.com/assets/images/frontend/blog/thumb_65ccecbfe51fc1707928767.jpg",
  blog2: "https://hr-y.com/assets/images/frontend/blog/thumb_65d0ca81514851708182145.jpg",
  blog3: "https://hr-y.com/assets/images/frontend/blog/thumb_65cceb0bc1fe71707928331.jpg",
  client1: "https://hr-y.com/assets/images/frontend/client/632ffa2e77de91664088622.jpg",
  client2: "https://hr-y.com/assets/images/frontend/client/632ffa49a88501664088649.jpg",
  client3: "https://hr-y.com/assets/images/frontend/client/632ffa6954cd11664088681.jpg",
  client4: "https://hr-y.com/assets/images/frontend/client/632ffa86877431664088710.png",
  client5: "https://hr-y.com/assets/images/frontend/client/632ffaa211a7d1664088738.jpg",
};

// Client Testimonials - أسماء وشركات حقيقية
export const testimonials = [
  { nameAr: "أحمد الشريف", nameEn: "Ahmed Al-Sharif", companyAr: "مصنع الشريف للبلاستيك", companyEn: "Al-Sharif Plastics Factory", rating: 5, textAr: "تعاملنا مع حسام ردمان في استيراد خطوط إنتاج كاملة من الصين وتركيا. الاحترافية في التخليص الجمركي والشحن البحري جعلت العملية سلسة تماماً. ننصح بهم بقوة.", textEn: "We worked with Hussam Radman importing full production lines from China and Turkey. Their professionalism in customs clearance and sea shipping made the process completely smooth." },
  { nameAr: "خالد المتوكل", nameEn: "Khalid Al-Mutawakkil", companyAr: "شركة المتوكل للتجارة", companyEn: "Al-Mutawakkil Trading Co.", rating: 5, textAr: "أفضل شركة تخليص جمركي تعاملت معها في اليمن. السرعة في الإنجاز والشفافية في الأسعار هي ما يميزهم. شحناتنا تصل دائماً في الوقت المحدد.", textEn: "Best customs clearance company I've dealt with in Yemen. Speed of execution and price transparency is what distinguishes them. Our shipments always arrive on time." },
  { nameAr: "سامي الحميدي", nameEn: "Sami Al-Humaidi", companyAr: "مجموعة الحميدي التجارية", companyEn: "Al-Humaidi Trading Group", rating: 5, textAr: "استخدمنا خدمة الشراء من المواقع العالمية وكانت التجربة ممتازة. الفريق يتابع الطلبات بدقة ويقدم تقارير تفصيلية عن كل شحنة. تطبيق شحنات سهّل علينا كثيراً.", textEn: "We used the global website shopping service and the experience was excellent. The team tracks orders precisely and provides detailed reports for every shipment." },
  { nameAr: "عبدالله الصنعاني", nameEn: "Abdullah Al-Sanaani", companyAr: "مؤسسة الصنعاني للمقاولات", companyEn: "Al-Sanaani Construction Est.", rating: 5, textAr: "نستورد معدات ثقيلة من أوروبا وأمريكا، وحسام ردمان يتولى كل شيء من الشحن البحري إلى التخليص إلى التوصيل النهائي. خدمة متكاملة بحق.", textEn: "We import heavy equipment from Europe and USA, and Hussam Radman handles everything from sea shipping to clearance to final delivery. A truly integrated service." },
  { nameAr: "محمد العولقي", nameEn: "Mohammed Al-Awlaki", companyAr: "شركة العولقي للاستيراد والتصدير", companyEn: "Al-Awlaki Import & Export Co.", rating: 5, textAr: "خدمة المزايدة على السيارات من كوبارت وIAA كانت احترافية جداً. الفريق يفهم السوق ويقدم نصائح قيّمة قبل المزايدة. وفّروا علينا الكثير.", textEn: "The car auction bidding service on Copart and IAA was very professional. The team understands the market and provides valuable pre-bidding advice." },
  { nameAr: "ياسر الكبسي", nameEn: "Yasser Al-Kabsi", companyAr: "مصنع الكبسي للمواد الغذائية", companyEn: "Al-Kabsi Food Factory", rating: 5, textAr: "نتعامل مع حسام ردمان منذ أكثر من 5 سنوات في استيراد المواد الخام. الالتزام بالمواعيد والاحتساب الشامل المسبق ساعدنا في التخطيط المالي بشكل كبير.", textEn: "We've been working with Hussam Radman for over 5 years importing raw materials. Their on-time commitment and pre-costing helped us greatly with financial planning." },
  { nameAr: "فاطمة النهمي", nameEn: "Fatima Al-Nahmi", companyAr: "متجر فاطمة الإلكتروني", companyEn: "Fatima Online Store", rating: 5, textAr: "كتاجرة إلكترونية، أحتاج شراء من مواقع متعددة مثل شي إن وعلي إكسبرس. خدمة الشراء والشحن الموحد وفّرت عليّ الوقت والتكلفة. تطبيق شحنات ممتاز للتتبع.", textEn: "As an e-commerce seller, I need to buy from multiple sites like Shein and AliExpress. The unified buying and shipping service saved me time and cost." },
  { nameAr: "نبيل المخلافي", nameEn: "Nabil Al-Makhlafi", companyAr: "شركة المخلافي للسيارات", companyEn: "Al-Makhlafi Motors Co.", rating: 5, textAr: "نشتري سيارات من المزادات الأمريكية واليابانية والخليجية. حسام ردمان هو الشريك الذي نثق به في كل مراحل العملية من المزايدة حتى التسليم.", textEn: "We buy cars from American, Japanese and Gulf auctions. Hussam Radman is the partner we trust in every stage from bidding to delivery." },
];

// Team Members - Complete list from hr-y.com/team
export const teamMembers = [
  { id: 1, nameAr: "حسام ردمان", nameEn: "Hussam Radman", roleAr: "المدير العام", roleEn: "General Manager", year: 2004, img: "https://hr-y.com/wp/1.jpg", department: "management" },
  { id: 2, nameAr: "محمد ردمان", nameEn: "Mohammed Radman", roleAr: "المدير التنفيذي", roleEn: "Executive Director", year: 2006, img: "https://hr-y.com/wp/15.png", department: "management" },
  { id: 3, nameAr: "سام ردمان", nameEn: "Sam Radman", roleAr: "الشؤون المالية", roleEn: "Financial Affairs", year: 2006, img: "https://hr-y.com/wp/4.png", department: "finance" },
  { id: 4, nameAr: "محمد الربادي", nameEn: "Mohammed Al-Rabadi", roleAr: "مدير المكتب", roleEn: "Office Manager", year: 2008, img: "https://hr-y.com/wp/5.png", department: "management" },
  { id: 5, nameAr: "رضوان المنصري", nameEn: "Radwan Al-Mansouri", roleAr: "شؤون الموظفين", roleEn: "HR Manager", year: 2009, img: "https://hr-y.com/wp/21.png", department: "hr" },
  { id: 6, nameAr: "عبدالرحمن الراعي", nameEn: "Abdul Rahman Al-Raie", roleAr: "العلاقات العامة", roleEn: "Public Relations", year: 2009, img: "https://hr-y.com/wp/20.png", department: "pr" },
  { id: 7, nameAr: "حسن الكليبي", nameEn: "Hassan Al-Kulaibi", roleAr: "الشؤون القانونية", roleEn: "Legal Affairs", year: 2009, img: "https://hr-y.com/wp/18.png", department: "legal" },
  { id: 8, nameAr: "محمد حميد", nameEn: "Mohammed Hamid", roleAr: "مختص تخليص", roleEn: "Clearance Specialist", year: 2010, img: "https://hr-y.com/wp/2.png", department: "clearance" },
  { id: 9, nameAr: "اكرم الدماجي", nameEn: "Akram Al-Damaji", roleAr: "مختص تخليص", roleEn: "Clearance Specialist", year: 2014, img: "https://hr-y.com/wp/14.png", department: "clearance" },
  { id: 10, nameAr: "علي السعواني", nameEn: "Ali Al-Saawani", roleAr: "مختص تخليص", roleEn: "Clearance Specialist", year: 2015, img: "https://hr-y.com/wp/22.png", department: "clearance" },
  { id: 11, nameAr: "بكيل الاصبحي", nameEn: "Bakil Al-Asbahi", roleAr: "مختص تخليص", roleEn: "Clearance Specialist", year: 2015, img: "https://hr-y.com/wp/7.png", department: "clearance" },
  { id: 12, nameAr: "طه العبيدي", nameEn: "Taha Al-Obaidi", roleAr: "مشرف التصاريح", roleEn: "Permits Supervisor", year: 2016, img: "https://hr-y.com/wp/9.png", department: "permits" },
  { id: 13, nameAr: "انور ردمان", nameEn: "Anwar Radman", roleAr: "مشرف النقل", roleEn: "Transport Supervisor", year: 2016, img: "https://hr-y.com/wp/3.png", department: "transport" },
  { id: 14, nameAr: "اصيل السامعي", nameEn: "Aseel Al-Samie", roleAr: "مدير التسويق", roleEn: "Marketing Manager", year: 2017, img: "https://hr-y.com/wp/12.png", department: "marketing" },
  { id: 15, nameAr: "ماجد كامل", nameEn: "Majid Kamel", roleAr: "مشرف عام", roleEn: "General Supervisor", year: 2018, img: "https://hr-y.com/wp/19.png", department: "operations" },
  { id: 16, nameAr: "عفيف ردمان", nameEn: "Afif Radman", roleAr: "إدارة المتابعة", roleEn: "Follow-up Management", year: 2019, img: "https://hr-y.com/wp/11.png", department: "operations" },
  { id: 17, nameAr: "اصيل السروري", nameEn: "Aseel Al-Surouri", roleAr: "مشرف عمليات الشحن", roleEn: "Shipping Operations Supervisor", year: 2020, img: "https://hr-y.com/wp/6.png", department: "shipping" },
  { id: 18, nameAr: "عبدالناصر العبيدي", nameEn: "Abdul Nasser Al-Obaidi", roleAr: "وحدة المشتريات", roleEn: "Procurement Unit", year: 2020, img: "https://hr-y.com/wp/17.png", department: "procurement" },
  { id: 19, nameAr: "اواب الكامل", nameEn: "Awab Al-Kamel", roleAr: "مختص تخليص", roleEn: "Clearance Specialist", year: 2020, img: "https://hr-y.com/wp/13.png", department: "clearance" },
  { id: 20, nameAr: "عمر الدماجي", nameEn: "Omar Al-Damaji", roleAr: "مختص تخليص", roleEn: "Clearance Specialist", year: 2021, img: "https://hr-y.com/wp/10.png", department: "clearance" },
];

// Branches & Offices
export const branches = [
  { id: 1, cityAr: "صنعاء", cityEn: "Sana'a", typeAr: "المقر الرئيسي", typeEn: "Headquarters", address: "شارع الزبيري", phone: "+967 1 234567", services: ["customs", "shipping", "consulting"] },
  { id: 2, cityAr: "عدن", cityEn: "Aden", typeAr: "فرع رئيسي", typeEn: "Main Branch", address: "ميناء عدن", phone: "+967 2 234567", services: ["customs", "shipping", "seaport"] },
  { id: 3, cityAr: "الحديدة", cityEn: "Al-Hodeidah", typeAr: "فرع", typeEn: "Branch", address: "ميناء الحديدة", phone: "+967 3 234567", services: ["customs", "seaport"] },
  { id: 4, cityAr: "المخا", cityEn: "Al-Mokha", typeAr: "فرع", typeEn: "Branch", address: "ميناء المخا", phone: "+967 4 234567", services: ["customs", "seaport"] },
  { id: 5, cityAr: "تعز", cityEn: "Taiz", typeAr: "فرع", typeEn: "Branch", address: "شارع جمال", phone: "+967 4 345678", services: ["customs", "shipping"] },
  { id: 6, cityAr: "المكلا", cityEn: "Al-Mukalla", typeAr: "فرع", typeEn: "Branch", address: "ميناء المكلا", phone: "+967 5 234567", services: ["customs", "seaport"] },
  { id: 7, cityAr: "الوديعة", cityEn: "Al-Wadiah", typeAr: "منفذ بري", typeEn: "Land Port", address: "منفذ الوديعة", phone: "+967 5 345678", services: ["customs", "landport"] },
  { id: 8, cityAr: "شحن", cityEn: "Shahen", typeAr: "منفذ بري", typeEn: "Land Port", address: "منفذ شحن", phone: "+967 5 456789", services: ["customs", "landport"] },
];

// Shipping Agencies & Partners
export const shippingAgencies = [
  { id: 1, nameAr: "ميرسك", nameEn: "Maersk", logo: "🚢", type: "sea" },
  { id: 2, nameAr: "إم إس سي", nameEn: "MSC", logo: "🚢", type: "sea" },
  { id: 3, nameAr: "هاباج لويد", nameEn: "Hapag-Lloyd", logo: "🚢", type: "sea" },
  { id: 4, nameAr: "إيفرجرين", nameEn: "Evergreen", logo: "🚢", type: "sea" },
  { id: 5, nameAr: "كوسكو", nameEn: "COSCO", logo: "🚢", type: "sea" },
  { id: 6, nameAr: "يانج مينج", nameEn: "Yang Ming", logo: "🚢", type: "sea" },
  { id: 7, nameAr: "دي إتش إل", nameEn: "DHL", logo: "✈️", type: "air" },
  { id: 8, nameAr: "فيديكس", nameEn: "FedEx", logo: "✈️", type: "air" },
  { id: 9, nameAr: "يو بي إس", nameEn: "UPS", logo: "✈️", type: "air" },
  { id: 10, nameAr: "أرامكس", nameEn: "Aramex", logo: "✈️", type: "air" },
  { id: 11, nameAr: "طيران الإمارات للشحن", nameEn: "Emirates SkyCargo", logo: "✈️", type: "air" },
  { id: 12, nameAr: "الخطوط السعودية للشحن", nameEn: "Saudia Cargo", logo: "✈️", type: "air" },
];

// E-commerce Websites for Shopping Service
export const shoppingWebsites = [
  { name: "Amazon", nameAr: "أمازون", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://amazon.com&size=64", region: "USA" },
  { name: "Alibaba", nameAr: "علي بابا", logo: "https://wembsmkt.com/images/1_wemb/icon/alibaba-icon.png", region: "China" },
  { name: "AliExpress", nameAr: "علي إكسبرس", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://aliexpress.com&size=64", region: "China" },
  { name: "Shein", nameAr: "شي إن", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://shein.com&size=64", region: "China" },
  { name: "Temu", nameAr: "تيمو", logo: "https://play-lh.googleusercontent.com/9v08ai07I8aoFLj5M-90nzWPpvyNzOVgA2ZWF9avdW7oS8L9YqF9trVI44SUn2qGTA0=s96-rw", region: "China" },
  { name: "Noon", nameAr: "نون", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://noon.com&size=64", region: "UAE" },
  { name: "eBay", nameAr: "إي باي", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://ebay.com&size=64", region: "USA" },
  { name: "Walmart", nameAr: "وول مارت", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://walmart.com&size=64", region: "USA" },
  { name: "iHerb", nameAr: "آي هيرب", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://iherb.com&size=64", region: "USA" },
  { name: "DHgate", nameAr: "دي إتش جيت", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://dhgate.com&size=64", region: "China" },
  { name: "Banggood", nameAr: "بانج جود", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://banggood.com&size=64", region: "China" },
  { name: "LightInTheBox", nameAr: "لايت إن ذا بوكس", logo: "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://lightinthebox.com&size=64", region: "China" },
];

// Auction Websites
export const auctionWebsites = [
  { name: "Copart", nameAr: "كوبارت", logo: "🚗", region: "USA", type: "cars" },
  { name: "IAA", nameAr: "آي إيه إيه", logo: "🚗", region: "USA", type: "cars" },
  { name: "Manheim", nameAr: "مانهايم", logo: "🚗", region: "USA", type: "cars" },
  { name: "OpenLane", nameAr: "أوبن لين", logo: "🚗", region: "USA", type: "cars" },
  { name: "Barrett-Jackson", nameAr: "باريت جاكسون", logo: "🚗", region: "USA", type: "cars" },
  { name: "Mecum", nameAr: "ميكوم", logo: "🚗", region: "USA", type: "cars" },
  { name: "USS Japan", nameAr: "يو إس إس اليابان", logo: "🚗", region: "Japan", type: "cars" },
  { name: "AAA Japan", nameAr: "إيه إيه إيه اليابان", logo: "🚗", region: "Japan", type: "cars" },
  { name: "Emirates Auction", nameAr: "الإمارات للمزادات", logo: "🚗", region: "UAE", type: "cars" },
  { name: "K Car", nameAr: "كي كار", logo: "🚗", region: "Korea", type: "cars" },
  { name: "BCA UK", nameAr: "بي سي إيه", logo: "🚗", region: "UK", type: "cars" },
  { name: "Autobid.de", nameAr: "أوتوبيد", logo: "🚗", region: "Germany", type: "cars" },
];

// Ports in Yemen
export const yemenPorts = {
  sea: [
    { nameAr: "ميناء عدن", nameEn: "Aden Port", type: "main" },
    { nameAr: "ميناء الحديدة", nameEn: "Hodeidah Port", type: "main" },
    { nameAr: "ميناء المخا", nameEn: "Mokha Port", type: "secondary" },
    { nameAr: "ميناء المكلا", nameEn: "Mukalla Port", type: "secondary" },
    { nameAr: "ميناء نشطون", nameEn: "Nishtun Port", type: "secondary" },
    { nameAr: "ميناء الصليف", nameEn: "Salif Port", type: "secondary" },
  ],
  land: [
    { nameAr: "منفذ الوديعة", nameEn: "Al-Wadiah Border", country: "Saudi Arabia" },
    { nameAr: "منفذ شحن", nameEn: "Shahen Border", country: "Oman" },
    { nameAr: "منفذ صرفيت", nameEn: "Sarfait Border", country: "Oman" },
    { nameAr: "منفذ حرض", nameEn: "Haradh Border", country: "Saudi Arabia" },
    { nameAr: "منفذ البقع", nameEn: "Al-Buqa Border", country: "Saudi Arabia" },
  ],
  air: [
    { nameAr: "مطار صنعاء الدولي", nameEn: "Sana'a International Airport" },
    { nameAr: "مطار عدن الدولي", nameEn: "Aden International Airport" },
    { nameAr: "مطار سيئون الدولي", nameEn: "Seiyun International Airport" },
  ],
};

// All Services with full details
export const services = [
  {
    id: "customs-clearance",
    icon: "ClipboardList",
    color: "from-orange-500 to-orange-600",
    titleAr: "التخليص الجمركي",
    titleEn: "Customs Clearance",
    shortAr: "خدمات التخليص الجمركي السريع والدقيق لجميع أنواع البضائع",
    shortEn: "Fast and accurate customs clearance for all types of goods",
    descAr: "نحن نقدم خدمات التخليص الجمركي السريع والدقيق لجميع أنواع البضائع في جمهورية اليمن. يتمتع فريقنا المتخصص بالخبرة والكفاءة اللازمة لإنجاز جميع الإجراءات الجمركية بدقة واحترافية في المنافذ البرية والبحرية والجوية داخل البلاد.",
    descEn: "We provide fast and accurate customs clearance services for all types of goods in Yemen. Our specialized team has the expertise and efficiency to complete all customs procedures accurately and professionally at land, sea, and air ports.",
    features: ["تخليص سريع خلال 24 ساعة", "فريق متخصص في جميع المنافذ", "متابعة مستمرة للشحنات", "أسعار تنافسية"],
    featuresEn: ["Fast clearance within 24 hours", "Specialized team at all ports", "Continuous shipment tracking", "Competitive prices"],
  },
  {
    id: "sea-shipping",
    icon: "Ship",
    color: "from-cyan-500 to-cyan-600",
    titleAr: "الشحن البحري",
    titleEn: "Sea Shipping",
    shortAr: "شحن الحاويات والبضائع عبر جميع الموانئ العالمية",
    shortEn: "Container and cargo shipping through all global ports",
    descAr: "نحن نقدم خدمة الشحن البحري السريع والدقيق للبضائع من جميع الموانئ البحرية باستخدام الحاويات، بمهنية وكفاءة عالية. نحن نضمن تسهيل وتسريع إجراءات الشحن في الموانئ، وضمان وصول الشحنات بسلاسة وفي الوقت المحدد.",
    descEn: "We provide fast and accurate maritime shipping services from all seaports using containers, with high professionalism and efficiency. We ensure smooth and timely delivery of shipments.",
    features: ["شحن حاويات كاملة FCL", "شحن أقل من حاوية LCL", "تتبع الشحنات", "تأمين البضائع"],
    featuresEn: ["Full Container Load FCL", "Less than Container Load LCL", "Shipment tracking", "Cargo insurance"],
  },
  {
    id: "air-shipping",
    icon: "Plane",
    color: "from-sky-500 to-sky-600",
    titleAr: "الشحن الجوي",
    titleEn: "Air Freight",
    shortAr: "شحن جوي سريع للبضائع العاجلة والحساسة",
    shortEn: "Fast air freight for urgent and sensitive goods",
    descAr: "خدمة الشحن الجوي السريع للبضائع العاجلة مع ضمان الوصول في أسرع وقت ممكن. نتعامل مع جميع شركات الطيران العالمية لضمان أفضل الأسعار وأسرع الأوقات.",
    descEn: "Fast air freight service for urgent goods with guaranteed fastest possible delivery. We work with all major airlines for the best prices and fastest times.",
    features: ["وصول خلال 3-5 أيام", "شحن المواد الحساسة", "تتبع لحظي", "تغطية عالمية"],
    featuresEn: ["Delivery in 3-5 days", "Sensitive material shipping", "Real-time tracking", "Global coverage"],
  },
  {
    id: "land-transport",
    icon: "Truck",
    color: "from-emerald-500 to-emerald-600",
    titleAr: "النقل البري",
    titleEn: "Land Transport",
    shortAr: "خدمات النقل البري بين جميع المحافظات والدول المجاورة",
    shortEn: "Land transport between all governorates and neighboring countries",
    descAr: "نحن نقدم خدمات النقل البري بين جميع المحافظات في اليمن والدول المجاورة باستخدام مجموعة متنوعة من الشاحنات، نحرص على تقديم أفضل الأسعار وأرقى المواصفات لضمان سلامة وجودة النقل.",
    descEn: "We provide land transport services between all governorates in Yemen and neighboring countries using various trucks, ensuring the best prices and highest specifications for safe and quality transport.",
    features: ["شاحنات متنوعة الأحجام", "تغطية كل المحافظات", "نقل دولي", "تأمين شامل"],
    featuresEn: ["Various truck sizes", "All governorates coverage", "International transport", "Full insurance"],
  },
  {
    id: "website-shopping",
    icon: "ShoppingCart",
    color: "from-blue-500 to-blue-600",
    titleAr: "الشراء من المواقع",
    titleEn: "Website Shopping",
    shortAr: "خدمة شاملة للشراء من المواقع العالمية والشحن إلى اليمن",
    shortEn: "Complete shopping service from global websites and shipping to Yemen",
    descAr: "نحن نقدم خدمة شاملة للشراء والشحن من مختلف المواقع العالمية والأسواق الإلكترونية الشهيرة مثل أمازون، علي بابا، علي إكسبرس، شي إن، تيمو، نون وغيرها. نحن نساعدك في إتمام عمليات الدفع، وتنظيم عمليات الشحن إلى الجمهورية اليمنية.",
    descEn: "We provide comprehensive buying and shipping services from various global websites and famous e-commerce platforms like Amazon, Alibaba, AliExpress, Shein, Temu, Noon, and more.",
    features: ["الدفع نيابة عنك", "تجميع الطلبات", "شحن موحد", "متابعة الطلبات"],
    featuresEn: ["Payment on your behalf", "Order consolidation", "Unified shipping", "Order tracking"],
  },
  {
    id: "auction-bidding",
    icon: "Gavel",
    color: "from-rose-500 to-rose-600",
    titleAr: "المزايدة من المواقع",
    titleEn: "Auction Bidding",
    shortAr: "خدمة المزايدة والشراء من مواقع المزادات العالمية",
    shortEn: "Bidding and buying service from global auction websites",
    descAr: "خدمة المزايدة والشراء من مواقع المزادات العالمية مثل كوبارت، IAA، مانهايم ومزادات السيارات في أمريكا وأوروبا واليابان والخليج. نتولى عملية المزايدة والدفع والشحن بالكامل.",
    descEn: "Bidding and buying from global auction sites like Copart, IAA, Manheim, and car auctions in USA, Europe, Japan, and Gulf. We handle the entire bidding, payment, and shipping process.",
    features: ["مزادات السيارات", "مزادات المعدات", "فحص قبل الشراء", "شحن دولي"],
    featuresEn: ["Car auctions", "Equipment auctions", "Pre-purchase inspection", "International shipping"],
  },
  {
    id: "cost-calculation",
    icon: "Calculator",
    color: "from-purple-500 to-purple-600",
    titleAr: "الاحتساب الشامل",
    titleEn: "Cost Calculation",
    shortAr: "احتساب شامل لتكاليف الاستيراد والضرائب والرسوم",
    shortEn: "Comprehensive calculation of import costs, taxes, and fees",
    descAr: "نحن نقدم خدمة الاحتساب الشامل لتكاليف الاستيراد، حيث نقوم بتقدير وتحليل جميع النفقات المتعلقة بعملية الاستيراد بدقة، بما في ذلك الجمارك، الرسوم اللوجستية، الضرائب، رسوم الشحن والتخليص الجمركي.",
    descEn: "We provide comprehensive import cost calculation service, accurately estimating and analyzing all expenses related to the import process, including customs, logistics fees, taxes, and clearance fees.",
    features: ["تقدير الجمارك", "حساب الضرائب", "رسوم الشحن", "التكاليف الإضافية"],
    featuresEn: ["Customs estimation", "Tax calculation", "Shipping fees", "Additional costs"],
  },
  {
    id: "customs-consulting",
    icon: "Briefcase",
    color: "from-indigo-500 to-indigo-600",
    titleAr: "الاستشارات الجمركية",
    titleEn: "Customs Consulting",
    shortAr: "استشارات متخصصة في القوانين واللوائح الجمركية",
    shortEn: "Specialized consulting on customs laws and regulations",
    descAr: "نحن نقدم خدمات استشارات جمركية شاملة تهدف إلى مساعدة العملاء في التعامل مع القوانين واللوائح الجمركية. نحن نوفر الإرشادات والتوجيه فيما يتعلق بالتخليص الجمركي، وإعداد الوثائق، وتقديم الحلول المبتكرة.",
    descEn: "We provide comprehensive customs consulting services to help clients deal with customs laws and regulations. We offer guidance on customs clearance, documentation, and innovative solutions.",
    features: ["استشارات قانونية", "تصنيف البضائع", "الاتفاقيات التجارية", "حل المشاكل"],
    featuresEn: ["Legal consulting", "Goods classification", "Trade agreements", "Problem solving"],
  },
  {
    id: "permits",
    icon: "FileCheck",
    color: "from-teal-500 to-teal-600",
    titleAr: "استخراج التصاريح",
    titleEn: "Permit Extraction",
    shortAr: "استخراج جميع التصاريح المطلوبة للاستيراد والتصدير",
    shortEn: "Extraction of all required permits for import and export",
    descAr: "نحن نقدم خدمة استخراج جميع التصاريح المطلوبة للعملاء لأنشطتهم التجارية أو الاستيراد والتصدير. نحن ندير الإجراءات القانونية والإدارية ونسهل عملية الحصول على التصاريح بكفاءة.",
    descEn: "We provide extraction of all required permits for clients' commercial activities or import and export. We manage legal and administrative procedures efficiently.",
    features: ["تصاريح الاستيراد", "تصاريح التصدير", "الرخص التجارية", "الموافقات الحكومية"],
    featuresEn: ["Import permits", "Export permits", "Commercial licenses", "Government approvals"],
  },
  {
    id: "parcel-shipping",
    icon: "Package",
    color: "from-amber-500 to-amber-600",
    titleAr: "شحن الطرود",
    titleEn: "Parcel Shipping",
    shortAr: "شحن الطرود والكميات الصغيرة بأمان وسرعة",
    shortEn: "Safe and fast parcel and small quantity shipping",
    descAr: "نحن نقدم خدمة الشحن الجزئي بالطرود للعملاء الذين يحتاجون إلى شحن كميات صغيرة من البضائع. نقوم بتغليف الطرود بعناية وتوفير وسائل النقل المناسبة لضمان وصولها بسرعة وأمان.",
    descEn: "We provide partial parcel shipping for clients who need to ship small quantities of goods. We carefully package parcels and provide appropriate transport to ensure fast and safe delivery.",
    features: ["تغليف آمن", "تتبع الطرود", "توصيل سريع", "أسعار مناسبة"],
    featuresEn: ["Safe packaging", "Parcel tracking", "Fast delivery", "Affordable prices"],
  },
  {
    id: "warehousing",
    icon: "Warehouse",
    color: "from-lime-600 to-lime-700",
    titleAr: "التخزين",
    titleEn: "Warehousing",
    shortAr: "خدمات التخزين المحلية والدولية بأعلى المعايير",
    shortEn: "Local and international storage services with highest standards",
    descAr: "خدمة التخزين المحلية والدولية للبضائع مع ضمان الحفاظ عليها في أفضل الظروف. نوفر مستودعات مجهزة في مواقع استراتيجية قريبة من الموانئ والمطارات.",
    descEn: "Local and international warehousing service with guaranteed optimal conditions. We provide equipped warehouses in strategic locations near ports and airports.",
    features: ["مستودعات مكيفة", "حراسة 24 ساعة", "جرد إلكتروني", "مواقع استراتيجية"],
    featuresEn: ["Climate-controlled", "24/7 security", "Electronic inventory", "Strategic locations"],
  },
  {
    id: "source-finding",
    icon: "Search",
    color: "from-pink-500 to-pink-600",
    titleAr: "البحث عن مصادر",
    titleEn: "Source Finding",
    shortAr: "البحث عن المصانع والموردين المناسبين عالمياً",
    shortEn: "Finding suitable factories and suppliers globally",
    descAr: "نقدم خدمة فريدة تهدف إلى تسهيل عملية العثور على أفضل المصادر والتواصل مع المصانع العالمية لشراء البضائع. نقوم بإجراء بحث دقيق لتحديد المصانع التي تلبي احتياجاتك بأفضل الأسعار والجودة.",
    descEn: "We offer a unique service to help find the best sources and communicate with global factories to purchase goods. We conduct thorough research to identify factories that meet your needs at the best prices and quality.",
    features: ["بحث شامل", "تفاوض الأسعار", "فحص الجودة", "عينات مجانية"],
    featuresEn: ["Comprehensive search", "Price negotiation", "Quality inspection", "Free samples"],
  },
];

// Additional Services from hr-y.com/app/
export const additionalServices = [
  { id: "travel", titleAr: "خدمة السفريات", titleEn: "Travel Services", items: [
    { ar: "حجز سفر جوي", en: "Air Travel Booking" },
    { ar: "حجز سفر بري", en: "Land Travel Booking" },
    { ar: "خدمات الجوازات", en: "Passport Services" },
    { ar: "حج وعمرة", en: "Hajj & Umrah" },
    { ar: "فيز عمل", en: "Work Visas" },
    { ar: "تصديق وثائق", en: "Document Authentication" },
  ]},
  { id: "car-services", titleAr: "خدمات السيارات", titleEn: "Car Services", items: [
    { ar: "التخليص الجمركي للسيارات", en: "Car Customs Clearance" },
    { ar: "الشحن البحري للسيارات", en: "Car Sea Shipping" },
    { ar: "مزايدة وشراء من المواقع", en: "Auction Bidding & Buying" },
    { ar: "النقل البري للسيارات", en: "Car Land Transport" },
  ]},
  { id: "gov-services", titleAr: "إنجاز معاملات حكومية", titleEn: "Government Services", items: [
    { ar: "مصلحة الضرائب", en: "Tax Authority" },
    { ar: "مصلحة الجمارك", en: "Customs Authority" },
    { ar: "الهيئة العامة للاستثمار", en: "Investment Authority" },
    { ar: "وزارة الصناعة والتجارة", en: "Ministry of Industry & Trade" },
    { ar: "وزارة الزراعة والري", en: "Ministry of Agriculture" },
    { ar: "هيئة مقاييس وضبط الجودة", en: "Standards Authority" },
    { ar: "الغرفة التجارية الصناعية", en: "Chamber of Commerce" },
  ]},
  { id: "tools", titleAr: "الأدوات المساعدة", titleEn: "AI-Powered Tools", items: [
    { ar: "حاسبة CBM بالذكاء الاصطناعي", en: "AI-Powered CBM Calculator" },
    { ar: "حاسبة البيان الجمركي", en: "Customs Declaration Calculator" },
    { ar: "التعرفة الجمركية", en: "Customs Tariff Lookup" },
    { ar: "القوانين الجمركية", en: "Customs Laws Database" },
    { ar: "الوثائق المطلوبة للاستيراد", en: "Import Documents Guide" },
    { ar: "أسعار العملات الجمركية", en: "Customs Currency Rates" },
    { ar: "مراجع سعرية ذكية", en: "Smart Price References" },
    { ar: "نظام المركبات", en: "Vehicle System" },
  ]},
  { id: "insurance", titleAr: "تأمين الشحن", titleEn: "Shipping Insurance", items: [
    { ar: "تأمين الشحن البحري", en: "Sea Shipping Insurance" },
    { ar: "تأمين الشحن البري", en: "Land Shipping Insurance" },
    { ar: "تأمين الشحن الجوي", en: "Air Shipping Insurance" },
  ]},
  { id: "door-to-door", titleAr: "من الباب إلى الباب", titleEn: "Door-to-Door", items: [
    { ar: "شحنة كاملة (شاحنات-حاويات)", en: "Full Load (Trucks-Containers)" },
    { ar: "جزئي (طرود)", en: "Partial (Parcels)" },
    { ar: "سيارات", en: "Vehicles" },
  ]},
];

// Yemeni Companies we work with
export const yemeniCompanies = [
  "مصنع الشريف للبلاستيك", "شركة المتوكل للتجارة", "مجموعة الحميدي التجارية",
  "مؤسسة الصنعاني للمقاولات", "شركة العولقي للاستيراد والتصدير", "مصنع الكبسي للمواد الغذائية",
  "شركة المخلافي للسيارات", "مصنع السلام للمنظفات", "شركة يمن سوفت للتقنية",
  "مجموعة هائل سعيد أنعم", "شركة الهاشمي التجارية", "مؤسسة بن سلمان للتجارة",
  "مصنع الحكيمي للحلويات", "شركة النجم للإلكترونيات", "مجموعة العيسي التجارية",
];

// Statistics
export const statistics = {
  yearsExperience: 20,
  happyClients: 5000,
  branches: 10,
  employees: 120,
  completedTransactions: 15000,
  countries: 50,
};

// App info
export const APP_INFO = {
  nameAr: "شحنات",
  nameEn: "SHANAT",
  descAr: "تطبيق شحنات هو منصة ذكية لإدارة جميع عمليات الشحن والتخليص الجمركي والشراء من المواقع العالمية، مدعوم بتقنيات الذكاء الاصطناعي لتقديم أفضل تجربة.",
  descEn: "SHANAT App is an intelligent platform for managing all shipping, customs clearance, and global shopping operations, powered by AI technology for the best experience.",
  url: "https://hr-y.com/app/",
};
